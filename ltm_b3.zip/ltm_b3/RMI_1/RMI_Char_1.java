import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.net.URLEncoder;
import RMI.CharacterService;

// Mã câu hỏi: TGOVMAdh
// Đề: Mã hóa URL (URL Encoding) cho chuỗi nhận được từ server.
//     Ví dụ: "Hello World!" -> "Hello%20World%21"
public class RMI_Char_1 {
    static final String HOST = "36.50.135.242";
    static final String MSV = "B22DCCN752";
    static final String QCODE = "TGOVMAdh";

    public static void main(String[] args) throws Exception {
        // a. Nhận chuỗi từ server
        Registry rg = LocateRegistry.getRegistry(HOST, 1099);
        CharacterService sv = (CharacterService) rg.lookup("RMICharacterService");
        String s = sv.requestCharacter(MSV, QCODE);
        System.out.println("Chuoi dau vao: " + s);

        // b. Mã hóa URL
        // URLEncoder mã hóa dấu cách thành '+', nhưng đề yêu cầu '%20' nên phải thay lại
        String res = URLEncoder.encode(s, "UTF-8").replace("+", "%20");
        System.out.println("Chuoi ma hoa  : " + res);

        // c. Gửi chuỗi đã mã hóa lại server
        sv.submitCharacter(MSV, QCODE, res);
        System.out.println("Da gui: " + res);
    }
}
