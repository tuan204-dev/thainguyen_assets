#!/usr/bin/env bash
# Compile + chay mot bai RMI tu terminal (khong phu thuoc IDE).
#
#   ./run.sh                    -> chi compile, liet ke cac bai co the chay
#   ./run.sh RMI_Byte_1         -> chay THAT: goi request + submit  => NOP BAI
#   ./run.sh --dry RMI_Byte_1   -> chay THU : goi request, KHONG submit => khong nop
#
# Che do --dry copy code sang thu muc tam va chi vo hieu hoa loi goi submit*,
# phan thuat toan giu nguyen tung ky tu, nen ket qua in ra dung bang luc nop that.
# Luu y: server tra du lieu NGAU NHIEN moi lan request, nen so lieu luc --dry
# se khac luc chay that; --dry dung de kiem tra chuong trinh chay tron va logic dung.

set -euo pipefail
cd "$(dirname "$0")"

DRY=0
if [ "${1:-}" = "--dry" ]; then DRY=1; shift; fi

OUT=out
rm -rf "$OUT"
javac -encoding UTF-8 -d "$OUT" RMI/*.java ./*.java
echo "[ok] Compile xong -> $OUT/"

if [ $# -eq 0 ]; then
  echo
  echo "Cac bai co the chay:"
  for f in RMI_*.java; do
    printf '  ./run.sh %-14s (nop that)   |  ./run.sh --dry %s\n' "${f%.java}" "${f%.java}"
  done
  exit 0
fi

MAIN="$1"
if [ ! -f "$MAIN.java" ]; then
  echo "[loi] Khong tim thay $MAIN.java trong $(pwd)" >&2
  exit 1
fi

MSV=$(sed -n 's/.*String MSV *= *"\([^"]*\)".*/\1/p' "$MAIN.java" | head -1)
QCODE=$(sed -n 's/.*String QCODE *= *"\([^"]*\)".*/\1/p' "$MAIN.java" | head -1)

if [ "$DRY" = "0" ]; then
  echo "[run] $MAIN   MSV=$MSV   QCODE=$QCODE   -- CHAY THAT, SE NOP BAI"
  echo
  exec java -cp "$OUT" "$MAIN"
fi

# ---------- che do --dry ----------
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
cp -R RMI "$TMP"/
cp "$MAIN.java" "$TMP"/
sed -i.bak \
  -e 's/sv\.submitData(/DryRun.submitData(/' \
  -e 's/sv\.submitCharacter(/DryRun.submitCharacter(/' \
  -e 's/sv\.submitObject(/DryRun.submitObject(/' \
  "$TMP/$MAIN.java"
rm -f "$TMP/$MAIN.java.bak"

cat > "$TMP/DryRun.java" <<'JAVA'
import java.util.Arrays;
public class DryRun {
    public static void submitData(String msv, String q, byte[] d) {
        System.out.println(">>> [DRY-RUN] KHONG nop. Payload = byte[] " + Arrays.toString(d));
    }
    public static void submitData(String msv, String q, Object d) {
        System.out.println(">>> [DRY-RUN] KHONG nop. Payload = " + d.getClass().getName() + " " + d);
    }
    public static void submitCharacter(String msv, String q, String d) {
        System.out.println(">>> [DRY-RUN] KHONG nop. Payload = String \"" + d + "\"");
    }
    public static void submitObject(String msv, String q, java.io.Serializable d) {
        System.out.println(">>> [DRY-RUN] KHONG nop. Payload = " + d.getClass().getName() + " " + d);
    }
}
JAVA

javac -encoding UTF-8 -d "$TMP" "$TMP"/RMI/*.java "$TMP"/*.java
echo "[dry] $MAIN   MSV=$MSV   QCODE=$QCODE   -- KHONG nop bai"
echo
java -cp "$TMP" "$MAIN"
