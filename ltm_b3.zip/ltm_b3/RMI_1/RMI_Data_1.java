import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.ArrayList;
import java.util.List;
import RMI.DataService;

// Mã câu hỏi: RfLvEfgS
// Đề: Nhận mảng số nguyên, tìm các ĐỈNH CỤC BỘ.
//     Một phần tử là đỉnh cục bộ nếu lớn hơn phần tử liền kề bên trái VÀ bên phải;
//     phần tử đầu/cuối chỉ cần lớn hơn phần tử kề duy nhất.
//     Trả về vị trí theo chỉ số bắt đầu từ 1.  Ví dụ: [3,8,5,10,7] -> [2,4]
public class RMI_Data_1 {
    static final String HOST = "36.50.135.242";
    static final String MSV = "B22DCCN752";
    static final String QCODE = "RfLvEfgS";

    public static void main(String[] args) throws Exception {
        // a. Nhận dữ liệu từ server
        Registry rg = LocateRegistry.getRegistry(HOST, 1099);
        DataService sv = (DataService) rg.lookup("RMIDataService");
        Object obj = sv.requestData(MSV, QCODE);
        List<Integer> a = toIntList(obj);
        System.out.println("Mang nhan duoc: " + a);

        // b. Tìm vị trí các đỉnh cục bộ (chỉ số bắt đầu từ 1)
        int n = a.size();
        ArrayList<Integer> res = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            boolean trai = (i == 0) || a.get(i) > a.get(i - 1);          // đầu mảng: bỏ qua bên trái
            boolean phai = (i == n - 1) || a.get(i) > a.get(i + 1);      // cuối mảng: bỏ qua bên phải
            if (trai && phai) res.add(i + 1);
        }
        System.out.println("Vi tri dinh cuc bo: " + res);

        // c. Gửi List<Integer> các vị trí đỉnh cục bộ lại server
        sv.submitData(MSV, QCODE, res);
        System.out.println("Da gui: " + res);
    }

    // Server có thể trả về int[], Integer[], List hoặc chuỗi "3,8,5,10,7" -> quy về List<Integer>
    static List<Integer> toIntList(Object obj) {
        ArrayList<Integer> a = new ArrayList<>();
        if (obj instanceof int[]) {
            for (int x : (int[]) obj) a.add(x);
        } else if (obj instanceof Object[]) {
            for (Object x : (Object[]) obj) a.add(((Number) x).intValue());
        } else if (obj instanceof List<?>) {
            for (Object x : (List<?>) obj) a.add(((Number) x).intValue());
        } else {
            String s = String.valueOf(obj).replace("[", " ").replace("]", " ").replace(",", " ");
            for (String x : s.trim().split("\\s+")) if (!x.isEmpty()) a.add(Integer.parseInt(x));
        }
        return a;
    }
}
