package RMI;
import java.io.Serializable;

// LƯU Ý: Nếu đề thi có cung cấp sẵn file TicketSla.java thì DÙNG FILE CỦA ĐỀ (ghi đè file này),
// vì serialVersionUID và tên field phải khớp với lớp phía server thì mới deserialize được.
// File này là bản dựng theo mô tả đề: priority=HIGH;openedHoursAgo=10 -> breached=true;action=ESCALATE_L1
//
// serialVersionUID = 20260517 lấy từ chính server 36.50.135.242:1099 (đã dò bằng requestObject;
// giá trị cũ 1L gây java.io.InvalidClassException ngay ở bước nhận đối tượng).
public class TicketSla implements Serializable {
    private static final long serialVersionUID = 20260517L;
    private String priority;        // CRITICAL | HIGH | MEDIUM | LOW
    private int openedHoursAgo;     // số giờ đã mở
    private boolean breached;       // có vi phạm SLA hay không
    private String action;          // MONITOR | ESCALATE_L1 | ESCALATE_L2

    public TicketSla() {}
    public TicketSla(String priority, int openedHoursAgo) {
        this.priority = priority;
        this.openedHoursAgo = openedHoursAgo;
    }
    public String getPriority() { return priority; }
    public void setPriority(String priority) { this.priority = priority; }
    public int getOpenedHoursAgo() { return openedHoursAgo; }
    public void setOpenedHoursAgo(int openedHoursAgo) { this.openedHoursAgo = openedHoursAgo; }
    public boolean isBreached() { return breached; }
    public void setBreached(boolean breached) { this.breached = breached; }
    public String getAction() { return action; }
    public void setAction(String action) { this.action = action; }

    @Override
    public String toString() {
        return "priority=" + priority + ";openedHoursAgo=" + openedHoursAgo
             + ";breached=" + breached + ";action=" + action;
    }
}
