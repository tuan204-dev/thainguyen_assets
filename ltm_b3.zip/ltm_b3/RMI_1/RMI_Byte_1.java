import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import RMI.ByteService;

// Mã câu hỏi: EY7bQq1U
// Đề: Tìm phần tử có SỐ LẦN XUẤT HIỆN ÍT NHẤT trong mảng byte[].
//     Nếu nhiều phần tử cùng số lần xuất hiện ít nhất -> lấy phần tử ĐẦU TIÊN xuất hiện.
//     Ví dụ: [1, 2, 3, 2, 1] -> phần tử ít nhất là 3.
//     Gửi lại mảng byte gồm: {phần tử, số lần xuất hiện}.
public class RMI_Byte_1 {
    static final String HOST = "36.50.135.242";
    static final String MSV = "B22DCCN752";
    static final String QCODE = "EY7bQq1U";

    public static void main(String[] args) throws Exception {
        // a. Nhận dữ liệu từ server
        Registry rg = LocateRegistry.getRegistry(HOST, 1099);
        ByteService sv = (ByteService) rg.lookup("RMIByteService");
        byte[] a = sv.requestData(MSV, QCODE);
        for (byte x : a) System.out.print(x + " ");
        System.out.println();

        // b. Đếm tần suất rồi tìm phần tử có số lần xuất hiện ít nhất
        // Dùng (x & 0xFF) vì byte trong Java có dấu (-128..127), tránh lỗi chỉ số âm
        int[] cnt = new int[256];
        for (byte x : a) cnt[x & 0xFF]++;
        byte ptu = a[0];
        int sl = cnt[a[0] & 0xFF];
        for (byte x : a) {              // duyệt theo thứ tự mảng, so sánh "<" nên giữ phần tử đầu tiên khi hòa
            if (cnt[x & 0xFF] < sl) {
                ptu = x;
                sl = cnt[x & 0xFF];
            }
        }
        System.out.println("Phan tu it nhat = " + ptu + ", so lan = " + sl);

        // c. Gửi kết quả {phần tử, số lần xuất hiện} lên server
        byte[] res = { ptu, (byte) sl };
        sv.submitData(MSV, QCODE, res);
        System.out.println("Da gui: [" + res[0] + ", " + res[1] + "]");
    }
}
