import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import RMI.CharacterService;

// Mã câu hỏi: L8yEZIOF
// Đề: Chuyển số thập phân nhận được thành chuỗi số La Mã.
//     I=1, V=5, X=10, L=50, C=100, D=500, M=1000.  Ví dụ: 58 -> "LVIII"
public class RMI_Char_2 {
    static final String HOST = "36.50.135.242";
    static final String MSV = "B22DCCN752";
    static final String QCODE = "L8yEZIOF";

    public static void main(String[] args) throws Exception {
        // a. Nhận chuỗi (số thập phân) từ server
        Registry rg = LocateRegistry.getRegistry(HOST, 1099);
        CharacterService sv = (CharacterService) rg.lookup("RMICharacterService");
        String s = sv.requestCharacter(MSV, QCODE);
        System.out.println("So thap phan: " + s);

        // b. Đổi thập phân -> La Mã bằng thuật toán tham lam
        int dec = Integer.parseInt(s.trim());
        int[] tp = { 1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1 };            // thập phân
        String[] lm = { "M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I" }; // la mã
        String res = "";
        for (int i = 0; i < tp.length; i++) {
            while (dec >= tp[i]) {
                res += lm[i];
                dec -= tp[i];
            }
        }
        System.out.println("So La Ma    : " + res);

        // c. Gửi chuỗi số La Mã lại server
        sv.submitCharacter(MSV, QCODE, res);
        System.out.println("Da gui: " + res);
    }
}
