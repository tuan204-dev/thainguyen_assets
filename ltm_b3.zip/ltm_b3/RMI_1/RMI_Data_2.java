import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Locale;
import RMI.DataService;

// Mã câu hỏi: S7rjjBKw
// Đề: Nhận chuỗi CSV các số thực. Tính giá trị trung bình, độ lệch chuẩn trên toàn bộ dãy
//     và phân vị 95 tại vị trí ceil(n * 0.95) - 1 sau khi sắp xếp tăng dần.
//     Gửi chuỗi average=<avg>;stddev=<stddev>;p95=<p95>, làm tròn 2 chữ số thập phân.
//     Ví dụ: 10.00,20.00,30.00,40.00 -> average=25.00;stddev=11.18;p95=40.00
public class RMI_Data_2 {
    static final String HOST = "36.50.135.242";
    static final String MSV = "B22DCCN752";
    static final String QCODE = "S7rjjBKw";

    public static void main(String[] args) throws Exception {
        // a. Nhận dữ liệu từ server
        Registry rg = LocateRegistry.getRegistry(HOST, 1099);
        DataService sv = (DataService) rg.lookup("RMIDataService");
        String s = String.valueOf(sv.requestData(MSV, QCODE));
        System.out.println("Chuoi CSV: " + s);

        // b. Tách chuỗi thành dãy số thực
        ArrayList<Double> a = new ArrayList<>();
        String tmp = s.replace("[", " ").replace("]", " ").replace(",", " ");
        for (String x : tmp.trim().split("\\s+")) if (!x.isEmpty()) a.add(Double.parseDouble(x));
        int n = a.size();

        // Trung bình
        double tong = 0;
        for (double x : a) tong += x;
        double avg = tong / n;

        // Độ lệch chuẩn (theo tổng thể: chia cho n) — khớp ví dụ 10,20,30,40 -> 11.18
        double tongTmp = 0;
        for (double x : a) tongTmp += (x - avg) * (x - avg);
        double stddev = Math.sqrt(tongTmp / n);

        // Phân vị 95: sắp xếp tăng dần rồi lấy phần tử tại ceil(n * 0.95) - 1
        Collections.sort(a);
        int idx = (int) Math.ceil(n * 0.95) - 1;
        if (idx < 0) idx = 0;
        if (idx > n - 1) idx = n - 1;
        double p95 = a.get(idx);

        // c. Gửi kết quả — Locale.US để dấu thập phân luôn là '.' chứ không phải ','
        String res = String.format(Locale.US, "average=%.2f;stddev=%.2f;p95=%.2f", avg, stddev, p95);
        System.out.println(res);
        sv.submitData(MSV, QCODE, res);
        System.out.println("Da gui: " + res);
    }
}
