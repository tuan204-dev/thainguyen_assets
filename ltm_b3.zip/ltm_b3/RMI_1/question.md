# Đề RMI — Exam Server `36.50.135.242:1099`

## Cách chạy

> **Trước khi chạy: sửa hằng số `MSV` ở đầu mỗi file thành mã sinh viên của bạn.**
> Mỗi lần chạy là một lần nộp bài lên server, nên hãy kiểm tra `MSV` và `QCODE` trước.

### Cách 1 — terminal (nhanh nhất, không phụ thuộc IDE)

```bash
cd RMI_1
./run.sh                        # compile + liệt kê các bài
./run.sh --dry RMI_Byte_1       # CHẠY THỬ: gọi request, KHÔNG submit -> không tốn lượt nộp
./run.sh RMI_Byte_1             # CHẠY THẬT: request + submit -> NỘP BÀI
```

Chế độ `--dry` copy code sang thư mục tạm và chỉ vô hiệu hoá lời gọi `submit*`; phần thuật toán
giữ nguyên từng ký tự nên kết quả in ra đúng bằng lúc nộp thật. Dùng nó để chắc chắn chương trình
chạy trót lọt trước khi nộp. Lưu ý server trả dữ liệu **ngẫu nhiên mỗi lần request**, nên số liệu
lúc `--dry` sẽ khác lúc chạy thật.

Hoặc làm thủ công:

```bash
cd RMI_1
javac -encoding UTF-8 -d out RMI/*.java *.java
java -cp out RMI_Byte_1        # đổi tên lớp theo bài cần nộp
```

### Cách 2 — IntelliJ IDEA

Mở project `ltm_b3`, chọn cấu hình chạy `RMI_Byte_1` … `RMI_Object_1` ở góc trên bên phải rồi bấm ▶.
Bảy cấu hình này đã có sẵn trong `.idea/runConfigurations/`.

### Cấu hình project (đã sửa)

`ltm_b3` là một module Java, **chỉ `RMI_1` được đặt làm source root** — nhờ vậy
`RMI_1/RMI/*.java` khớp `package RMI`, còn `RMI_1/*.java` nằm ở default package.

Thư mục `WebService/` bị **đánh dấu excluded**: các file trong đó `import vn.medianews.*`,
mà package này không có trong project và cũng không có file `.jar` nào. Trước đây `WebService/`
nằm trong source root nên bước *Make* của IntelliJ luôn lỗi `package vn.medianews does not exist`
→ không sinh ra file `.class` nào → bấm Run cũng không chạy được `RMI_1`.
Muốn dùng lại phần `WebService` thì phải bổ sung thư viện `vn.medianews` rồi bỏ `excludeFolder`
tương ứng trong `ltm_b3.iml`.

VS Code dùng `.vscode/settings.json` ở thư mục gốc để lấy `RMI_1` làm source path và bỏ qua
`WebService/`, nên không còn lỗi `package does not match` / `import RMI cannot be resolved`.

### Đã kiểm chứng trên server thật (chạy `--dry`, không nộp)

Cả 7 bài đều chạy trót lọt end-to-end với dữ liệu thật của `36.50.135.242:1099`.

- `RMI/TicketSla.java`: `serialVersionUID` **phải là `20260517L`** — giá trị này dò được từ chính
  server. Để `1L` như bản dựng ban đầu thì `RMI_Object_1` ném `InvalidClassException` ngay ở
  `requestObject`, chưa kịp nộp gì. Tên và kiểu field của bản dựng khớp server (nhận về đúng
  `priority=CRITICAL;openedHoursAgo=30`).
- ⚠️ `RMI_Char_1`: server có gửi ký tự `*`, và `URLEncoder` của Java **không** mã hoá `*`
  (cũng như `-`, `_`, `.`). Nếu chấm điểm bằng `URLEncoder` phía Java thì hiện tại là đúng; nếu
  chấm theo kiểu Python/PHP (`*` → `%2A`) thì phải thêm `.replace("*", "%2A")`. Đề chỉ cho ví dụ
  `"Hello World!"` → `"Hello%20World%21"`, mà `!` → `%21` đúng hành vi của `URLEncoder`
  (còn `encodeURIComponent` của JS thì giữ nguyên `!`), nên khả năng cao bản hiện tại là đúng.

## Bảng tra

| File | Mã câu hỏi | Dịch vụ | Nội dung |
|---|---|---|---|
| `RMI_Byte_1.java` | `EY7bQq1U` | RMIByteService | Phần tử xuất hiện **ít nhất** |
| `RMI_Byte_2.java` | `E6SUYjl2` | RMIByteService | Phần tử xuất hiện **nhiều nhất** |
| `RMI_Char_1.java` | `TGOVMAdh` | RMICharacterService | Mã hóa URL |
| `RMI_Char_2.java` | `L8yEZIOF` | RMICharacterService | Thập phân → La Mã |
| `RMI_Data_1.java` | `RfLvEfgS` | RMIDataService | Vị trí các đỉnh cục bộ |
| `RMI_Data_2.java` | `S7rjjBKw` | RMIDataService | Trung bình, độ lệch chuẩn, p95 |
| `RMI_Object_1.java` | `612LEnse` | RMIObjectService | TicketSla — breached & action |

---

## 1. `EY7bQq1U` — ByteService, phần tử xuất hiện ít nhất

```java
public interface ByteService extends Remote {
    public byte[] requestData(String studentCode, String qCode) throws RemoteException;
    public void submitData(String studentCode, String qCode, byte[] data) throws RemoteException;
}
```

Interface `ByteService` viết trong package `RMI`, đăng ký với RegistryServer tên `RMIByteService`.

- a. Gọi `requestData` để nhận mảng `byte[]`.
- b. Tìm phần tử có số lần xuất hiện **ít nhất**; nếu nhiều phần tử cùng số lần xuất hiện ít nhất
  thì lấy phần tử **đầu tiên xuất hiện**. Ví dụ `[1, 2, 3, 2, 1]` → phần tử `3`.
- c. Gọi `submitData` gửi mảng byte chứa phần tử đó và số lần xuất hiện.
- d. Kết thúc chương trình client.

## 2. `E6SUYjl2` — ByteService, phần tử xuất hiện nhiều nhất

- a. Gọi `requestData` để nhận mảng `byte[]`.
- b. Tìm phần tử xuất hiện **nhiều nhất**; nếu nhiều phần tử cùng tần suất cao nhất thì lấy phần tử
  **đầu tiên xuất hiện**. Ví dụ `[1, 2, 3, 2, 1, 2]` → phần tử `2`, tần suất `3`.
- c. Gọi `submitData` gửi mảng byte chứa phần tử phổ biến nhất cùng tần suất của nó.
- d. Kết thúc chương trình client.

## 3. `TGOVMAdh` — CharacterService, mã hóa URL

```java
public interface CharacterService extends Remote {
    public String requestCharacter(String studentCode, String qCode) throws RemoteException;
    public void submitCharacter(String studentCode, String qCode, String strSubmit) throws RemoteException;
}
```

Đăng ký với RegistryServer tên `RMICharacterService`.

- a. Gọi `requestCharacter` để nhận chuỗi ngẫu nhiên, định dạng: "Chuỗi đầu vào".
- b. Mã hóa URL: thay ký tự đặc biệt bằng `%` + mã ASCII.
  Ví dụ `"Hello World!"` → `"Hello%20World%21"`.
- c. Gọi `submitCharacter` gửi chuỗi đã mã hóa trở lại server.
- d. Kết thúc chương trình client.

## 4. `L8yEZIOF` — CharacterService, thập phân → La Mã

- a. Gọi `requestCharacter` để nhận chuỗi, định dạng: "Số thập phân đầu vào".
- b. Chuyển số thập phân thành chuỗi số La Mã. I=1, V=5, X=10, L=50, C=100, D=500, M=1000.
  Ví dụ `58` → `"LVIII"`.
- c. Gọi `submitCharacter` gửi chuỗi số La Mã trở lại server.
- d. Kết thúc chương trình client.

## 5. `RfLvEfgS` — DataService, đỉnh cục bộ

Giao diện `DataService` trong package `RMI`, đăng ký tên `RMIDataService`.

- a. Dùng mã sinh viên và mã câu hỏi làm tham số khi gọi RMI.
- b. Gọi `requestData(studentCode, qCode)` để nhận một mảng số nguyên. Ví dụ `[3,8,5,10,7]`.
- c. Một phần tử là đỉnh cục bộ nếu lớn hơn phần tử liền kề bên trái và bên phải; phần tử đầu/cuối
  chỉ cần lớn hơn phần tử kề duy nhất. Trả về vị trí theo chỉ số bắt đầu từ 1.
- d. Gọi `submitData(studentCode, qCode, data)` để gửi `List<Integer>` các vị trí đỉnh cục bộ.
  Ví dụ `[2,4]`.
- e. Kết thúc chương trình client.

## 6. `S7rjjBKw` — DataService, trung bình / độ lệch chuẩn / p95

- a. Dùng mã sinh viên và mã câu hỏi làm tham số khi gọi RMI.
- b. Gọi `requestData(studentCode, qCode)` để nhận chuỗi CSV các số thực.
  Ví dụ `10.00,20.00,30.00,40.00`.
- c. Tính giá trị trung bình, độ lệch chuẩn trên toàn bộ dãy và phân vị 95 tại vị trí
  `ceil(n * 0.95) - 1` sau khi sắp xếp tăng dần.
- d. Gọi `submitData(studentCode, qCode, data)` gửi chuỗi `average=<avg>;stddev=<stddev>;p95=<p95>`,
  các số thực làm tròn 02 chữ số thập phân. Ví dụ `average=25.00;stddev=11.18;p95=40.00`.
- e. Kết thúc chương trình client.

## 7. `612LEnse` — ObjectService, TicketSla

Giao diện `ObjectService` trong package `RMI`, đăng ký tên `RMIObjectService`.

- a. Dùng mã sinh viên và mã câu hỏi làm tham số khi gọi RMI.
- b. Gọi `requestObject(studentCode, qCode)` để nhận đối tượng `RMI.TicketSla`.
  Ví dụ `priority=HIGH;openedHoursAgo=10`.
- c. Thiết lập `breached` nếu `CRITICAL > 2h`, `HIGH > 8h`, `MEDIUM > 24h`, hoặc `LOW > 72h`.
  Nếu không vi phạm, đặt `action=MONITOR`; nếu vi phạm và priority là `CRITICAL` hoặc thời gian mở
  trên `96h`, đặt `ESCALATE_L2`; các trường hợp vi phạm còn lại đặt `ESCALATE_L1`.
- d. Gọi `submitObject(studentCode, qCode, object)` để gửi lại đối tượng đã cập nhật.
  Ví dụ `breached=true;action=ESCALATE_L1`.
- e. Kết thúc chương trình client.
