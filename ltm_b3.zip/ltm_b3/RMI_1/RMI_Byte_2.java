import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import RMI.ByteService;

// Mã câu hỏi: E6SUYjl2
// Đề: Tìm phần tử XUẤT HIỆN NHIỀU NHẤT trong mảng byte[].
//     Nếu nhiều phần tử cùng số lần xuất hiện cao nhất -> lấy phần tử ĐẦU TIÊN xuất hiện.
//     Ví dụ: [1, 2, 3, 2, 1, 2] -> phần tử 2, tần suất 3.
//     Gửi lại mảng byte gồm: {phần tử, tần suất}.
public class RMI_Byte_2 {
    static final String HOST = "36.50.135.242";
    static final String MSV = "B22DCCN752";
    static final String QCODE = "E6SUYjl2";

    public static void main(String[] args) throws Exception {
        // a. Nhận dữ liệu từ server
        Registry rg = LocateRegistry.getRegistry(HOST, 1099);
        ByteService sv = (ByteService) rg.lookup("RMIByteService");
        byte[] a = sv.requestData(MSV, QCODE);
        for (byte x : a) System.out.print(x + " ");
        System.out.println();

        // b. Đếm tần suất rồi tìm phần tử xuất hiện nhiều nhất
        int[] cnt = new int[256];
        for (byte x : a) cnt[x & 0xFF]++;
        byte ptu = a[0];
        int sl = cnt[a[0] & 0xFF];
        for (byte x : a) {              // so sánh ">" nên giữ phần tử đầu tiên khi hòa
            if (cnt[x & 0xFF] > sl) {
                ptu = x;
                sl = cnt[x & 0xFF];
            }
        }
        System.out.println("Phan tu nhieu nhat = " + ptu + ", tan suat = " + sl);

        // c. Gửi kết quả {phần tử, tần suất} lên server
        byte[] res = { ptu, (byte) sl };
        sv.submitData(MSV, QCODE, res);
        System.out.println("Da gui: [" + res[0] + ", " + res[1] + "]");
    }
}
