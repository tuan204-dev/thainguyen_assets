import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import RMI.ObjectService;
import RMI.TicketSla;

// Mã câu hỏi: 612LEnse
// Đề: Nhận đối tượng RMI.TicketSla (ví dụ priority=HIGH;openedHoursAgo=10).
//     - breached = true nếu CRITICAL > 2h, HIGH > 8h, MEDIUM > 24h, LOW > 72h.
//     - Nếu KHÔNG vi phạm            -> action = MONITOR
//     - Vi phạm & (CRITICAL hoặc > 96h) -> action = ESCALATE_L2
//     - Các trường hợp vi phạm còn lại  -> action = ESCALATE_L1
public class RMI_Object_1 {
    static final String HOST = "36.50.135.242";
    static final String MSV = "B22DCCN752";
    static final String QCODE = "612LEnse";

    public static void main(String[] args) throws Exception {
        // a. Nhận đối tượng từ server
        Registry rg = LocateRegistry.getRegistry(HOST, 1099);
        ObjectService sv = (ObjectService) rg.lookup("RMIObjectService");
        TicketSla t = (TicketSla) sv.requestObject(MSV, QCODE);
        System.out.println("Nhan duoc: " + t);

        // b. Xử lý đối tượng
        String p = t.getPriority().trim().toUpperCase();
        int h = t.getOpenedHoursAgo();

        boolean breached;
        switch (p) {
            case "CRITICAL": breached = h > 2;  break;
            case "HIGH":     breached = h > 8;  break;
            case "MEDIUM":   breached = h > 24; break;
            default:         breached = h > 72; break;   // LOW
        }

        String action;
        if (!breached) action = "MONITOR";
        else if (p.equals("CRITICAL") || h > 96) action = "ESCALATE_L2";
        else action = "ESCALATE_L1";

        t.setBreached(breached);
        t.setAction(action);
        System.out.println("breached=" + breached + ";action=" + action);

        // c. Gửi lại đối tượng đã cập nhật
        sv.submitObject(MSV, QCODE, t);
        System.out.println("Da gui: " + t);
    }
}
