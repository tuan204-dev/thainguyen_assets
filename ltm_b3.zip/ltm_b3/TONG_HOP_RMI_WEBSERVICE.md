# Tổng hợp bài tập Lập trình mạng — RMI & Web Service

Tài liệu này gộp toàn bộ mã nguồn trong hai thư mục [RMI 2/](RMI%202/) và [WebService/](WebService/) vào một file duy nhất: **35 bài RMI** + **28 bài Web Service**, kèm các lớp khung (interface dịch vụ, lớp mô hình, mẫu code 3 bước).

---

## Mục lục

- [Phần I — Nền tảng chung](#phần-i--nền-tảng-chung)
  - [1. Ba bước chuẩn của một bài thi](#1-ba-bước-chuẩn-của-một-bài-thi)
  - [2. Interface dịch vụ & khung code RMI](#2-interface-dịch-vụ--khung-code-rmi)
  - [3. Các lớp mô hình RMI](#3-các-lớp-mô-hình-rmi)
  - [4. Bảng tra thao tác Web Service](#4-bảng-tra-thao-tác-web-service)
  - [5. Mẹo xử lý hay dùng](#5-mẹo-xử-lý-hay-dùng)
- [Phần II — 35 bài RMI](#phần-ii--35-bài-rmi)
  - [A. DataService](#a-dataservice--9-bài)
  - [B. CharacterService](#b-characterservice--9-bài)
  - [C. ByteService](#c-byteservice--9-bài)
  - [D. ObjectService](#d-objectservice--8-bài)
- [Phần III — 28 bài Web Service](#phần-iii--28-bài-web-service)
  - [A. DataService](#a-dataservice--11-bài)
  - [B. CharacterService](#b-characterservice--8-bài)
  - [C. ObjectService](#c-objectservice--9-bài)

---

## Bảng tra nhanh toàn bộ bài

### RMI

| # | Bài | File | MSV | Mã đề |
|---|-----|------|-----|-------|
| 1 | Bộ ba Pythagore | `BoBaPytago.java` | `B21DCCN319` | `NMATI6Zw` |
| 2 | Liệt kê số nguyên tố | `LietKeSoNguyenTo.java` | `B21DCCN015` | `nD8MdtME` |
| 3 | Liệt kê số chính phương | `LietKeSoCP.java` | `B21DCCN028` | `eTHcAYZh` |
| 4 | Liệt kê số đối xứng | `LietKeSoDoiXung.java` | `B21DCCN021` | `t3cBY2uk` |
| 5 | Phân tích thừa số nguyên tố | `PhanTichTSNT.java` | `B21DCCN022` | `zzmmquoc` |
| 6 | Đổi tiền (tham lam) | `DoiTien.java` | `B21DCCN012` | `Iz06p8Zw` |
| 7 | Hoán vị kế tiếp | `HoanViTiepTheo.java` | `B21DCCN564` | `3Qe0Qb5w` |
| 8 | Sinh tổ hợp chập k | `SinhToHop.java` | `B21DCCN053` | `juC3u7C6` |
| 9 | Phương sai & độ lệch chuẩn | `PhuongSai.java` | `B21DCCN016` | `uZMEY3Zg` |
| 10 | La Mã → thập phân | `ChuyenDoiLaMaThapPhan.java` | `B21DCCN015` | `0JaasIw6` |
| 11 | Thập phân → La Mã | `ChuyenDoiThapPhanLaMa.java` | `B21DCCN032` | `ADu6zRYE` |
| 12 | Đếm số lần xuất hiện (dạng nén) | `DemSoLanXH1.java` | `B21DCCN564` | `U5BEBBOW` |
| 13 | Đếm số lần xuất hiện (dạng JSON) | `DemSoLanXH2.java` | `B21DCCN012` | `ctRfIejL` |
| 14 | Mã hóa Base64 | `MaHoaBase64.java` | `B21DCCN029` | `psd4Jmnt` |
| 15 | Mã hóa Caesar (xâu) | `MaHoaCaesar1.java` | `B21DCCN022` | `j4rStb2a` |
| 16 | Mã hóa Vigenère | `MaHoaVigen.java` | `B21DCCN021` | `Y7YMXHs4` |
| 17 | Mã hóa URL | `MaHoaURL.java` | `B21DCCN053` | `KkihaRAB` |
| 18 | Xử lý văn bản — tách chẵn/lẻ | `XuLyVanBan.java` | `B21DCCN319` | `NFldNPp6` |
| 19 | Giải mã Base64 | `GiaiMaBase64.java` | `B21DCCN015` | `oeJljCIf` |
| 20 | Mã hóa Hexa | `MaHoaHexa.java` | `B21DCCN032` | `pK0IZNnt` |
| 21 | Mã hóa Caesar (mảng byte) | `MaHoaCaesar2.java` | `B21DCCN028` | `i0EVI2TB` |
| 22 | Mã hóa XOR với khóa "PTIT" | `PhepXOR2.java` | `B21DCCN012` | `4BraNTI5` |
| 23 | Nén RLE | `NenRLE.java` | `B21DCCN036` | `2uG0lQGi` |
| 24 | Sắp xếp chẵn trước lẻ sau | `SapXepChanLe.java` | `B21DCCN029` | `A7hytb1V` |
| 25 | Phần tử xuất hiện nhiều nhất | `XHMax.java` | `B21DCCN319` | `1mPMIkGJ` |
| 26 | Phần tử xuất hiện ít nhất | `XHMin.java` | `B21DCCN564` | `L7A2NPQU` |
| 27 | Phần tử lớn thứ K | `LonThuK.java` | `B21DCCN066` | `uIKHCTWG` |
| 28 | Chuẩn hóa sản phẩm — Product | `XuLySanPham1.java` | `B21DCCN319` | `dx3nt4Ij` |
| 29 | Chuẩn hóa sản phẩm — ProductX | `XuLySanPham2.java` | `B21DCCN564` | `PY43T66m` |
| 30 | Tính lương nhân viên — Employee | `QuanLyNhanVien.java` | `B21DCCN038` | `7fSWnlHB` |
| 31 | Sinh mã sinh viên — Student | `QuanLySinhVien.java` | `B21DCCN023` | `lNV6xzmk` |
| 32 | Sinh mã sách — BookX | `QuanLyThuVien2.java` | `B21DCCN012` | `CoWosBho` |
| 33 | Sinh mã vé — Ticket | `QuanLySuKien.java` | `B21DCCN048` | `Uct8bABt` |
| 34 | Sinh mã sự kiện — Event | `ToChucSuKien.java` | `B21DCCN029` | `FKrGvwLM` |
| 35 | Sinh mã đơn hàng — Order | `TDMT.java` | `B21DCCN021` | `vLJWvWpf` |

### Web Service

| # | Bài | File | MSV | Mã đề |
|---|-----|------|-----|-------|
| 1 | Tổng các số | `TongCacSo.java` | `B21DCCN082` | `hnVAHv3I` |
| 2 | Liệt kê ước số | `LietKeUoc.java` | `B21DCCN004` | `nhFjYg0F` |
| 3 | Phân tích thừa số nguyên tố | `PTichTSNT.java` | `B21DCCN001` | `TwZpbqUg` |
| 4 | Đếm số lần xuất hiện | `DemSoLanXH.java` | `B21DCCN002` | `TU4ULIgh` |
| 5 | Loại bỏ phần tử trùng | `LoaiBoTrungNhau.java` | `B21DCCN033` | `E2Axwwf3` |
| 6 | Lớn/nhỏ thứ K | `LonNhoThuK.java` | `B21DCCN003` | `WpaUTFMu` |
| 7 | Sắp xếp xen kẽ chẵn — lẻ | `SXChanLe.java` | `B21DCCN088` | `0BEtJAT9` |
| 8 | Thập phân → nhị phân | `DecToBin.java` | `B21DCCN021` | `2jS1DTpU` |
| 9 | Hệ cơ số 8 và 16 | `HeCoSo8.java` | `B21DCCN025` | `QBDJ1GGL` |
| 10 | Số thập phân → phân số tối giản | `FractoDec.java` | `B21DCCN011` | `ny8Fb8BU` |
| 11 | Ghép số lớn nhất | `TimSoLonNhat.java` | `B21DCCN007` | `RiRH8wfk` |
| 12 | Đảo ngược ký tự chữ cái | `DaoNguoc.java` | `B21DCCN008` | `rT6Ql5GH` |
| 13 | Từ dài nhất & ngắn nhất (trong xâu) | `LenMaxMin.java` | `B21DCCN005` | `9n2rfqST` |
| 14 | Từ dài nhất & ngắn nhất (trong mảng) | `LenMaxMin2.java` | `B21DCCN010` | `sGJc3iD5` |
| 15 | Sắp xếp chuỗi theo độ dài | `SXTheoLen.java` | `B21DCCN003` | `mpu9xCxR` |
| 16 | Sắp xếp chuỗi theo số nguyên âm | `SapXepChuoi.java` | `B21DCCN002` | `x5TIDg1S` |
| 17 | Nhóm từ theo số nguyên âm | `NhomTuTheoNguyenAm.java` | `B21DCCN012` | `32He7sZg` |
| 18 | Chuẩn hóa chuỗi 3 kiểu | `ChuanHoaChuoi.java` | `B21DCCN007` | `sBQjqANT` |
| 19 | Xoay vòng ký tự | `XoayVongKyTu.java` | `B21DCCN016` | `YDcPHFgN` |
| 20 | Tính giá cuối — ProductY | `QuanLySanPham.java` | `B21DCCN002` | `itT8hvxF` |
| 21 | Đếm ngày công — Employee | `QuanLyNhanVien2.java` | `B21DCCN084` | `L8CainEX` |
| 22 | Phân loại học lực — Student | `PhanLoaiHocLuc.java` | `B21DCCN003` | `qNfIMvid` |
| 23 | Thủ khoa từng môn — StudentY | `QuanLySinhVien.java` | `B21DCCN001` | `2RjVBzv0` |
| 24 | Sắp xếp theo ngày vào làm — EmployeeY | `QuanLyNhanVien.java` | `B21DCCN004` | `vewbvojZ` |
| 25 | Khách hàng thân thiết — Customer | `QuanLyKhachHang.java` | `B21DCCN014` | `lgKj7lIF` |
| 26 | Khách hàng không hoạt động — CustomerY | `QuanLyKhachHang.java` | `B21DCCN005` | `aYiLQ3wo` |
| 27 | Dự án sắp tới hạn — Project | `QuanLyDuAn.java` | `B21DCCN010` | `R6UOuyyE` |
| 28 | Khách chi nhiều nhất — Order | `DonHang2.java` | `B21DCCN021` | `CuW1L0ev` |

---

## Phần I — Nền tảng chung

### 1. Ba bước chuẩn của một bài thi

Mọi bài trong tài liệu này đều theo đúng một khuôn:

| Bước | RMI | Web Service |
|------|-----|-------------|
| **a. Kết nối + nhận dữ liệu** | `LocateRegistry.getRegistry("203.162.10.109", 1099)` → `rg.lookup("RMI<X>Service")` → `request…(msv, qCode)` | `new <X>Service_Service()` → `service.get<X>ServicePort()` → `request…/get…(msv, qCode)` |
| **b. Xử lý** | Thuần Java, không liên quan tới mạng | Thuần Java, không liên quan tới mạng |
| **c. Gửi kết quả** | `submit…(msv, qCode, kq)` | `submit…(msv, qCode, kq)` |

Hai thứ **luôn phải sửa** khi làm bài mới: **mã sinh viên (`msv`)** và **mã câu hỏi (`qCode`)**. Trong kho code này chúng đã được điền sẵn theo bài gốc — xem cột MSV / Mã đề ở bảng tra trên.

> ⚠️ Vài file gốc bị lệch mã khi copy-paste giữa các bài (`LietKeSoNguyenTo.java` nhận `nD8MdtME` nhưng nộp lên `NMATI6Zw`; `SapXepChanLe.java` nhận bằng MSV `B21DCCN029` nhưng nộp bằng `B21DCCN028`). Code được giữ nguyên bản gốc — nhớ kiểm tra lại cặp mã ở bước c trước khi chạy.

### 2. Interface dịch vụ & khung code RMI

Bốn dịch vụ RMI đăng ký trên registry `203.162.10.109:1099`. Chọn dịch vụ theo kiểu dữ liệu đề cho:

| Dịch vụ | Tên lookup | Nhận về | Gửi đi |
|---------|-----------|---------|--------|
| `DataService` | `RMIDataService` | `Object` (phải ép kiểu) | `Object` |
| `CharacterService` | `RMICharacterService` | `String` | `String` |
| `ByteService` | `RMIByteService` | `byte[]` | `byte[]` |
| `ObjectService` | `RMIObjectService` | `Serializable` (phải ép kiểu) | `Serializable` |

### Interface DataService

**File gốc:** `RMI 2/DataService.java`

Nhận/gửi dữ liệu kiểu `Object` (số, xâu, danh sách…). Tên đăng ký: `RMIDataService`.

```java
package RMI;
import java.rmi.*;
public interface DataService extends Remote {
    public Object requestData(String studentCode, String qCode) throws RemoteException;
    public void submitData(String studentCode, String qCode, Object data) throws RemoteException;
}
```

### Interface CharacterService

**File gốc:** `RMI 2/CharacterService.java`

Nhận/gửi dữ liệu kiểu `String`. Tên đăng ký: `RMICharacterService`.

```java
package RMI;
import java.rmi.*;
public interface CharacterService extends Remote {
    public String requestCharacter(String studentCode, String qCode) throws RemoteException;
    public void submitCharacter(String studentCode, String qCode, String strSubmit) throws RemoteException;
}
```

### Interface ByteService

**File gốc:** `RMI 2/ByteService.java`

Nhận/gửi mảng `byte[]`. Tên đăng ký: `RMIByteService`.

```java
package RMI;
import java.rmi.*;
public interface ByteService extends Remote {
    public byte[] requestData(String studentCode, String qCode) throws RemoteException;
    public void submitData(String studentCode, String qCode, byte[] data) throws RemoteException;
}
```

### Interface ObjectService

**File gốc:** `RMI 2/ObjectService.java`

Nhận/gửi đối tượng `Serializable`. Tên đăng ký: `RMIObjectService`.

```java
package RMI;
import java.io.Serializable;
import java.rmi.Remote;
import java.rmi.RemoteException;
public interface ObjectService extends Remote {
    public Serializable requestObject(String studentCode, String qAlias) throws RemoteException;
    public void submitObject(String studentCode, String qAlias, Serializable object) throws RemoteException;
}
```

### Khung chung — dạng Data

**File gốc:** `RMI 2/Data.java`

Bộ khung 3 bước a-b-c cho mọi bài dùng `DataService`.

```java
import java.rmi.*;
import java.rmi.registry.*;
import java.util.*;
import RMI.DataService;
//Khung chung các bài làm dạng Data
public class Data {
    public static void main(String[] args) throws Exception {
        // a. Nhận dữ liệu
        Registry rg = LocateRegistry.getRegistry("203.162.10.109", 1099);
        DataService sv = (DataService) rg.lookup("RMIDataService");
        int N = (int) sv.requestData("B21DCCN319", "NMATI6Zw"); //Thay tương ứng MSV mã câu hỏi vào
        //Chú ý thay kiểu dữ liệu tương ứng và ép kiểu, cú pháp tương tự
        //Ví dụ đề bài cần String thì ghi: String x = (String)sv.requestData (MSV, mã đề)
        //Ta tiếp tục xử lý với inp nhận được...
        
        // b. Xử lý: 
        //Tuỳ vào đề thi, các bạn sẽ cần gửi trả lại server một cái gì đấy, xâu, số, v.v..
        //Ở đây mình giả sử sau 1001 bước xử lý thì kết quả ta thu được là một biến int res chẳng hạn
        int res = 0;
        // c. Gửi kết quả
        sv.submitData("B21DCCN319", "NMATI6Zw", res); //Chú ý thay MSV mã đề tương ứng
    }
}
```

### Khung chung — dạng Character

**File gốc:** `RMI 2/Character.java`

Bộ khung 3 bước a-b-c cho mọi bài dùng `CharacterService`.

```java
package RMI;
import java.rmi.*;
import java.rmi.registry.*;
import java.util.*;
import RMI.CharacterService;
public class Character {
    public static void main(String[] args) throws Exception{
        //a.
        Registry rg = LocateRegistry.getRegistry("203.162.10.109", 1099);
        CharacterService sv = (CharacterService) rg.lookup("RMICharacterService");
        String s = sv.requestCharacter("B21DCCN015", "0JaasIw6"); //Thay MSV mã đề tương ứng
        
        //b. Xử lý
        //Giả sử với xâu s đề cho, các bận xử lý tỉ tỉ bước, rồi xâu cuối cùng thu được là xâu res gì đấy
        
        //c. Gửi
        sv.submitCharacter("B21DCCN015", "0JaasIw6", res);//Gửi xâu kq lên cho sv, thay msv mã đề và tên biến kq tương ứng
    }
}
```

### Khung chung — dạng Byte

**File gốc:** `RMI 2/Byte.java`

Bộ khung 3 bước a-b-c cho mọi bài dùng `ByteService`.

```java
package RMI;
import RMI.ByteService;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Base64;
public class Byte {
    public static void main(String[] args) throws Exception{
        // a. Nhận dữ liệu từ server
        Registry rg = LocateRegistry.getRegistry("203.162.10.109", 1099);
        ByteService sv = (ByteService) rg.lookup("RMIByteService");
        byte[] a = sv.requestData("B21DCCN015", "oeJljCIf"); //Thay MSV mã câu hỏi tương ứng
        // b. Xử lý
        //Giả sử sau rất nhiều bước xử lý, từ mảng byte []a, các bạn thu được mảng kết quả byte []ans
        // c. 
        sv.submitData("B21DCCN015", "oeJljCIf", ans); //Gửi lên sv, thay msv mã đề tương ứng
    }
}
```

### Khung chung — dạng Object

**File gốc:** `RMI 2/Object.java`

Bộ khung 3 bước a-b-c cho mọi bài dùng `ObjectService`.

```java
package RMI;
import java.rmi.*;
import java.rmi.registry.*;
import RMI.ObjectService;
//import RMI.tên lớp;
//Ví dụ
import RMI.Book;
public class Object {
    public static void main(String[] args) throws Exception{
        //a. Nhận đối tượng từ server
        Registry rg = LocateRegistry.getRegistry("203.162.10.109", 1099);
        ObjectService sv = (ObjectService) rg.lookup("RMIObjectService");
        //Tên lớp a = (Tên lớp)sv.requestObject(Mã sinh viên, Mã câu hỏi); //Chú ý ép kiểu
        //Ví dụ: 
        Book book = (Book) sv.requestObject("B21DCCN008", "nCOdwcKJ");
        
        //b. Xử lý đối tượng
        //Sau bước này, ta thu được đối tượng book đã xử lý chẳng hạn
        
        //c. Gửi lại
        sv.submitObject("B21DCCN008", "nCOdwcKJ", book);//Thay MSV mã câu hỏi và tên đối tượng tương ứng
    }
}
```

### 3. Các lớp mô hình RMI

Các lớp `Serializable` dùng chung cho nhóm bài `ObjectService`. Lưu ý `serialVersionUID` phải khớp với server.

### Book

**File gốc:** `RMI 2/Book.java`

Sách: `id, title, author, yearPublished, pageCount, code`.

```java
package RMI;
import java.io.Serializable;
public class Book implements Serializable {
    private static final long serialVersionUID = 20241123L;
    private String id, title, author;
    private int yearPublished, pageCount;
    private String code;
    public Book() {}
    public Book(String id, String title, String author, int yearPublished, int pageCount) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.yearPublished = yearPublished;
        this.pageCount = pageCount;
    }
    // Getters and Setters
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getAuthor() {
        return author;
    }
    public void setAuthor(String author) {
        this.author = author;
    }
    public int getYearPublished() {
        return yearPublished;
    }
    public void setYearPublished(int yearPublished) {
        this.yearPublished = yearPublished;
    }
    public int getPageCount() {
        return pageCount;
    }

    public void setPageCount(int pageCount) {
        this.pageCount = pageCount;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    @Override
    public String toString() {
        return "Book{" +
                "id='" + id + '\'' +
                ", title='" + title + '\'' +
                ", author='" + author + '\'' +
                ", yearPublished=" + yearPublished +
                ", pageCount=" + pageCount +
                ", code='" + code + '\'' +
                '}';
    }
}
```

### BookX

**File gốc:** `RMI 2/BookX.java`

Sách bản mở rộng: có `genre` thay cho `pageCount`.

```java
package RMI;
import java.io.Serializable;
public class BookX implements Serializable {
    private static final long serialVersionUID = 20241124L;
    private String id, title, author;
    private int yearPublished;
    private String genre, code;
    public BookX() {}
    public BookX(String id, String title, String author, int yearPublished, String genre) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.yearPublished = yearPublished;
        this.genre = genre;
        this.code = "";
    }
    //get set cứ insert tung hết ra

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getYearPublished() {
        return yearPublished;
    }

    public void setYearPublished(int yearPublished) {
        this.yearPublished = yearPublished;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    @Override
    public String toString() {
        return "BookX{" + "id=" + id + ", title=" + title + ", author=" + author + ", yearPublished=" + yearPublished + ", genre=" + genre + ", code=" + code + '}';
    }
    
    
}
```

### Employee

**File gốc:** `RMI 2/Employee.java`

Nhân viên: `baseSalary, finalSalary, experienceYears`.

```java
package RMI;
import java.io.Serializable;
public class Employee implements Serializable{
    private static final long serialVersionUID = 20241119L;
    private String id; 
    private String name; 
    private double baseSalary, finalSalary; 
    private int experienceYears;
    public Employee(){}
    public Employee(String id, String name, double baseSalary, int experienceYears) {
        this.id = id;
        this.name = name;
        this.baseSalary = baseSalary;
        this.experienceYears = experienceYears;
    }
    public double getBaseSalary() {
        return baseSalary;
    }
    public int getExperienceYears() {
        return experienceYears;
    }
    public void setFinalSalary(double finalSalary) {
        this.finalSalary = finalSalary;
    }
    @Override
    public String toString() {
        return "Employee{" + "id=" + id + ", name=" + name + ", baseSalary=" + baseSalary + ", finalSalary=" + finalSalary + ", experienceYears=" + experienceYears + '}';
    }
}
```

### Event

**File gốc:** `RMI 2/Event.java`

Sự kiện: `eventName, eventDate, expectedAttendance, eventCode`.

```java
package RMI;
import java.io.Serializable;
public class Event implements Serializable{
    private static final long serialVersionUID = 20241131L;
    private String id, eventName, eventDate, eventCode;
    private int expectedAttendance;
    public Event(){};
    public Event(String id, String eventName, String eventDate, int expectedAttendance){
        this.id = id;
        this.eventName = eventName;
        this.eventDate = eventDate;
        this.expectedAttendance = expectedAttendance;
    }
    public String getEventName() {
        return eventName;
    }
    public String getEventDate() {
        return eventDate;
    }
    public int getExpectedAttendance() {
        return expectedAttendance;
    }
    public void setEventCode(String eventCode) {
        this.eventCode = eventCode;
    }
    @Override
    public String toString() {
        return "Event{" + "id=" + id + ", eventName=" + eventName + ", eventDate=" + eventDate + ", eventCode=" + eventCode + ", expectedAttendance=" + expectedAttendance + '}';
    }
}
```

### Order

**File gốc:** `RMI 2/Order.java`

Đơn hàng: `customerCode, orderDate, shippingType, orderCode`.

```java
package RMI;
import java.io.Serializable;
public class Order implements Serializable {
    private static final long serialVersionUID = 20241132L;
    private String id, customerCode, orderDate, shippingType, orderCode;
    public Order() {}
    public Order(String id, String customerCode, String orderDate, String shippingType) {
        this.id = id;
        this.customerCode = customerCode;
        this.orderDate = orderDate;
        this.shippingType = shippingType;
    }
    public String getCustomerCode() {
        return customerCode;
    }
    public String getShippingType() {
        return shippingType;
    }
    public String getOrderDate() {
        return orderDate;
    }
    public void setOrderCode(String orderCode) {
        this.orderCode = orderCode;
    }
    @Override
    public String toString() {
        return "Order{" + "id=" + id + ", customerCode=" + customerCode + ", orderDate=" + orderDate + ", shippingType=" + shippingType + ", orderCode=" + orderCode + '}';
    }
}
```

### Product

**File gốc:** `RMI 2/Product.java`

Sản phẩm: `code, importPrice, exportPrice`.

```java
package RMI;
import java.io.Serializable;
public class Product implements Serializable {
    private static final long serialVersionUID = 20151107L;
    private String id;
    private String code;
    private double importPrice;
    private double exportPrice; 
    public Product() {}
    public Product(String id, String code, double importPrice, double exportPrice) {
        this.id = id;
        this.code = code;
        this.importPrice = importPrice;
        this.exportPrice = exportPrice;
    }
    public String getCode() {
        return code;
    }
    public void setCode(String code) {
        this.code = code;
    }
    public double getImportPrice() {
        return importPrice;
    }
    public void setExportPrice(double exportPrice) {
        this.exportPrice = exportPrice;
    }
    @Override
    public String toString() {
        return "Product{" +
                "id=" + id +
                ", code='" + code + '\'' +
                ", importPrice=" + importPrice +
                ", exportPrice=" + exportPrice +
                '}';
    }
}
```

### ProductX

**File gốc:** `RMI 2/ProductX.java`

Sản phẩm khuyến mãi: `discountCode, discount`.

```java
package RMI;
import java.io.Serializable;
public class ProductX implements Serializable {
    private static final long serialVersionUID = 20171107;
    private String id, code, discountCode;
    private int discount;
    public ProductX(String id, String code, String discountCode, int discount) {
        this.id = id;
        this.code = code;
        this.discountCode = discountCode;
        this.discount = discount;
    }
    public String getDiscountCode() {
        return discountCode;
    }
    public void setDiscount(int discount) {
        this.discount = discount;
    }
    @Override
    public String toString() {
        return "ProductX [id=" + id + ", code=" + code + ", discountCode=" + discountCode + ", discount=" + discount + "]";
    }
}
```

### Student

**File gốc:** `RMI 2/Student.java`

Sinh viên: `name, enrollmentYear, code`.

```java
package RMI;
import java.io.Serializable;
public class Student implements Serializable {
    private static final long serialVersionUID = 20241130L;
    private String id;
    private String name;
    private int enrollmentYear;
    private String code;
    public Student() {}
    public Student(String id, String name, int enrollmentYear) {
        this.id = id;
        this.name = name;
        this.enrollmentYear = enrollmentYear;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public int getEnrollmentYear() {
        return enrollmentYear;
    }
    public void setCode(String code) {
        this.code = code;
    }
    @Override
    public String toString() {
        return "Student{id=" + id + ", name='" + name + '\'' +
                ", enrollmentYear=" + enrollmentYear +
                ", code='" + code + '\'' + '}';
    }
}
```

### Ticket

**File gốc:** `RMI 2/Ticket.java`

Vé sự kiện: `eventName, saleDate, ticketCode`.

```java
package RMI;
import java.io.Serializable;
public class Ticket implements Serializable{
    private static final long serialVersionUID = 20241133L;
    private String id;
    private String eventName, saleDate, ticketCode;
    public Ticket(){}
    public Ticket(String id, String eventName, String saleDate) {
        this.id = id;
        this.eventName = eventName;
        this.saleDate = saleDate;
    }
    public String getEventName() {
        return eventName;
    }
    public String getSaleDate() {
        return saleDate;
    }
    public void setTicketCode(String ticketCode) {
        this.ticketCode = ticketCode;
    }
    @Override
    public String toString() {
        return "Ticket{" + "id=" + id + ", eventName=" + eventName + ", saleDate=" + saleDate + ", ticketCode=" + ticketCode + '}';
    }
}
```

### 4. Bảng tra thao tác Web Service

Bên Web Service, stub được sinh sẵn trong package `vn.medianews` (cùng với `net.java.dev.jaxb.array` cho các kiểu mảng). Ba cổng dịch vụ và các phương thức đã dùng trong kho bài:

| Cổng | Phương thức nhận | Phương thức gửi |
|------|------------------|-----------------|
| `DataService` | `getData` → `List<Integer>`<br>`getDataDouble` → `double` | `submitDataInt`<br>`submitDataString`<br>`submitDataIntArray`<br>`submitDataStringArray` |
| `CharacterService` | `requestString` → `String`<br>`requestStringArray` → `List<String>`<br>`requestCharacter` → `List<Integer>` | `submitCharacterString`<br>`submitCharacterStringArray`<br>`submitCharacterCharArray` |
| `ObjectService` | `requestEmployee`, `requestProductY`,<br>`requestListStudent`, `requestListStudentY`,<br>`requestListEmployeeY`, `requestListCustomer`,<br>`requestListCustomerY`, `requestListProject`,<br>`requestListOrder` | `submitEmployee`, `submitProductY`,<br>`submitListStudent`, `submitListStudentY`,<br>`submitListEmployeeY`, `submitListCustomer`,<br>`submitListCustomerY`, `submitListProject`,<br>`submitListOrder` |

Khung chung cho mọi bài Web Service:

```java
import vn.medianews.*;
import java.util.*;

public class Bai {
    public static void main(String[] args) throws Exception {
        String msv = "B21DCCNxxx", qCode = "xxxxxxxx";
        // a. Tạo cổng dịch vụ và nhận dữ liệu
        DataService_Service service = new DataService_Service();
        DataService port = service.getDataServicePort();
        List<Integer> a = port.getData(msv, qCode);
        // b. Xử lý ... -> kết quả ans
        // c. Gửi kết quả
        port.submitDataIntArray(msv, qCode, ans);
    }
}
```

### 5. Mẹo xử lý hay dùng

Các đoạn lặp đi lặp lại trong hầu hết bài làm:

```java
// Tách xâu số phân cách bằng dấu phẩy và/hoặc khoảng trắng
s = s.replace(",", " ");
String[] tmp = s.trim().split("\\s+");

// Tách dạng "<phần 1>;<phần 2>"
int idx = s.indexOf(";");
String s1 = s.substring(0, idx), s2 = s.substring(idx + 1);

// Đếm tần suất ký tự / số nhỏ
int[] cnt = new int[256];
for (char x : s.toCharArray()) cnt[x]++;

// Viết hoa chữ cái đầu, còn lại thường
Character.toUpperCase(s.charAt(0)) + s.substring(1).toLowerCase()

// XMLGregorianCalendar (Web Service) -> LocalDate
String t = x.getDueDate().toString().substring(0, 10);
LocalDate d = LocalDate.parse(t);
long soNgay = ChronoUnit.DAYS.between(LocalDate.now(), d);

// Bỏ dấu phân cách thừa ở cuối chuỗi kết quả
res = res.substring(0, res.length() - 1);

// byte -> hexa (nhớ & 0xFF vì byte trong Java có dấu)
String.format("%02x", x & 0xFF)
```

---

## Phần II — 35 bài RMI

### A. DataService — 9 bài

### 1. Bộ ba Pythagore

**File gốc:** `RMI 2/code/BoBaPytago.java`  |  **MSV:** `B21DCCN319`  |  **Mã đề:** `NMATI6Zw`

Nhận số `N`, duyệt 3 vòng lặp tìm mọi bộ `(a<b<c) ≤ N` thỏa `a²+b²=c²`, gửi về `List<List<Integer>>`.

```java
package RMI.B21DCCN319;
import java.rmi.*;
import java.rmi.registry.*;
import java.util.*;
import RMI.DataService;
public class BoBaPytago {
    public static void main(String[] args) throws Exception {
        // a. Nhận dữ liệu
        Registry rg = LocateRegistry.getRegistry("203.162.10.109", 1099);
        DataService sv = (DataService) rg.lookup("RMIDataService");
        int N = (int) sv.requestData("B21DCCN319", "NMATI6Zw");
        System.out.println(N);
        // b. Xử lý: Tìm danh sách các bộ ba số Pythagore
        List<List<Integer>> res = new ArrayList<>();
        for (int a = 1; a <= N; a++) {
            for (int b = a + 1; b <= N; b++) {
                for (int c = b + 1; c <= N; c++) {
                    if (a * a + b * b == c * c) {
                        List<Integer> triple = new ArrayList<>();
                        triple.add(a); triple.add(b); triple.add(c);
                        res.add(triple);
                    }
                }
            }
        }
        System.out.println(res);
        // c. Gửi kết quả
        sv.submitData("B21DCCN319", "NMATI6Zw", res);
    }
}
```

### 2. Liệt kê số nguyên tố

**File gốc:** `RMI 2/code/LietKeSoNguyenTo.java`  |  **MSV:** `B21DCCN015`  |  **Mã đề:** `nD8MdtME`

Nhận `N`, liệt kê mọi số nguyên tố ≤ `N` bằng hàm `check` kiểm tra chia hết tới `√n`.

```java
package RMI.B21DCCN015;
import java.rmi.*;
import java.rmi.registry.*;
import java.util.*;
import RMI.DataService;
public class LietKeSoNguyenTo {
    public static void main(String[] args) throws Exception {
        // a. Nhận dữ liệu
        Registry rg = LocateRegistry.getRegistry("203.162.10.109", 1099);
        DataService sv = (DataService) rg.lookup("RMIDataService");
        int N = (int) sv.requestData("B21DCCN015", "nD8MdtME");
        System.out.println(N);
        // b. Xử lý: Tìm list các SNT
        List<Integer> res = new ArrayList<>();
        for(int i = 2;i<=N;i++){
            if(check(i)==1) res.add(i);
        }
        System.out.println(res);
        // c. Gửi kết quả
        sv.submitData("B21DCCN015", "NMATI6Zw", res);
    }
    public static int check(int n){//ktra snt
        for(int i = 2;i*i<=n;i++){
            if(n%i==0) return 0;
        }
        return 1;
    }
}
```

### 3. Liệt kê số chính phương

**File gốc:** `RMI 2/code/LietKeSoCP.java`  |  **MSV:** `B21DCCN028`  |  **Mã đề:** `eTHcAYZh`

Nhận `n`, lọc các số `i < n` mà `√i` là số nguyên.

```java
package RMI.B21DCCN028;
import RMI.DataService;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.*;
public class LietKeSoCP {
    public static boolean check(int x){
        double y = Math.sqrt(x);
        int y1 = (int)y;
        return y == y1;
    }
    public static void main(String[] args) throws Exception{
        Registry rg = LocateRegistry.getRegistry("203.162.10.109", 1099);
        DataService sv = (DataService) rg.lookup("RMIDataService");
        int n = (int) sv.requestData("B21DCCN028", "eTHcAYZh");
        System.out.println(n);
        List<Integer>a = new ArrayList<>();
        for(int i = 1;i<n;i++){
            if(check(i)) a.add(i);
        }
        System.out.println(a);
        sv.submitData("B21DCCN028", "eTHcAYZh", a);
    }
}
```

### 4. Liệt kê số đối xứng

**File gốc:** `RMI 2/code/LietKeSoDoiXung.java`  |  **MSV:** `B21DCCN021`  |  **Mã đề:** `t3cBY2uk`

Nhận xâu `"n;k"`, tách 2 số rồi liệt kê các số palindrome trong `[n, k)`.

```java
package RMI.B21DCCN021;
import RMI.DataService;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.*;
public class LietKeSoDoiXung {
    public static boolean check(int x){
        String s = x+"";
        for(int i = 0;i<=s.length()/2;i++){
            if(s.charAt(i)!=s.charAt(s.length() - i - 1)) return false;
        }
        return true;
    }
    public static void main(String[] args) throws Exception{
        Registry rg = LocateRegistry.getRegistry("203.162.10.109", 1099);
        DataService sv = (DataService) rg.lookup("RMIDataService");
        String s = (String) sv.requestData("B21DCCN021", "t3cBY2uk");
        System.out.println(s);
        s = s.replace(";", "");
        String []tmp = s.trim().split("\\s+");
        int n = Integer.parseInt(tmp[0].trim()), k = Integer.parseInt(tmp[1].trim());
        List<Integer>a = new ArrayList<>();
        for(int i = n;i<k;i++){
            if(check(i)) a.add(i);
        }
        System.out.println(a);
        sv.submitData("B21DCCN021", "t3cBY2uk", a);
    }
}
```

### 5. Phân tích thừa số nguyên tố

**File gốc:** `RMI 2/code/PhanTichTSNT.java`  |  **MSV:** `B21DCCN022`  |  **Mã đề:** `zzmmquoc`

Nhận `n`, chia liên tục cho các ước `i` từ 2 tới `√n`, phần dư > 1 là thừa số cuối.

```java
package RMI.B21DCCN022;
import java.util.*;
import RMI.DataService;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
public class PhanTichTSNT {
    public static void main(String[] args) throws Exception{
        Registry rg = LocateRegistry.getRegistry("203.162.10.109", 1099);
        DataService sv = (DataService) rg.lookup("RMIDataService");
        int n = (int) sv.requestData("B21DCCN022", "zzmmquoc");
        System.out.println(n);
        List<Integer>a = new ArrayList<>();
        for(int i = 2;i*i<=n;i++){
            while(n%i==0){
                a.add(i);
                n/=i;
            }
        }
        if(n>1) a.add(n);
        System.out.println(a);
        sv.submitData("B21DCCN022", "zzmmquoc", a);
    }
}
```

### 6. Đổi tiền (tham lam)

**File gốc:** `RMI 2/code/DoiTien.java`  |  **MSV:** `B21DCCN012`  |  **Mã đề:** `Iz06p8Zw`

Nhận `n`, tham lam theo mệnh giá `{10, 5, 2, 1}`. Kết quả `"<số tờ>; <danh sách tờ>"`, không đổi được thì `-1`.

```java
package RMI.B21DCCN012;
import java.rmi.*;
import java.rmi.registry.*;
import java.util.*;
import RMI.DataService;
public class DoiTien {
    public static void main(String[] args) throws Exception {
        // a. Nhận dữ liệu
        Registry rg = LocateRegistry.getRegistry("203.162.10.109", 1099);
        DataService sv = (DataService) rg.lookup("RMIDataService");
        int n = (int) sv.requestData("B21DCCN012", "Iz06p8Zw"), res = 0;
        System.out.println(n);
        // b. Xử lý: Tìm số đồng tiền
        String ans = "";
        int[] a = {1, 2, 5, 10}; 
        for (int i = 3; i >= 0; i--) {
            int p = n / a[i]; 
            if (p > 0) {
                res += p; 
                n -= p * a[i]; 
                for (int j = 0; j < p; j++) ans+=a[i] + ",";
            }
        }
        if (n > 0) ans = "-1";
        else {
            ans = ans.substring(0, ans.length() - 1);
            ans= String.format("%d; ", res) + ans;
        }
        System.out.println(ans);
        // c. Gửi kết quả
        sv.submitData("B21DCCN012", "Iz06p8Zw", ans);
    }
}
```

### 7. Hoán vị kế tiếp

**File gốc:** `RMI 2/code/HoanViTiepTheo.java`  |  **MSV:** `B21DCCN564`  |  **Mã đề:** `3Qe0Qb5w`

Thuật toán next-permutation: tìm `i` giảm từ cuối → tìm `j` lớn hơn `a[i]` → swap → lật đoạn sau `i`. Hết hoán vị thì quay về dãy tăng dần.

```java
package RMI.B21DCCN564;
import java.rmi.*;
import java.rmi.registry.*;
import java.util.*;
import RMI.DataService;
public class HoanViTiepTheo {
    public static void main(String[] args) throws Exception {
        // a. Nhận dữ liệu
        Registry rg = LocateRegistry.getRegistry("203.162.10.109", 1099);
        DataService sv = (DataService) rg.lookup("RMIDataService");
        String s = (String) sv.requestData("B21DCCN564", "3Qe0Qb5w");
        System.out.println(s);
        //Đẩy hết vào mảng để xử lý
        s = s.replace(",", " ");
        String[] tmp = s.trim().split("\\s+");
        ArrayList<Integer> a = new ArrayList<>();
        for (String x : tmp) a.add(Integer.parseInt(x));
        int n = a.size();
        //b. Sinh hoán vị kế tiếp
        // Bước 1: Tìm vị trí đầu tiên từ cuối mà tại đó nó nhỏ hơn số đằng sau nó
        int i = n - 2;
        while (i >= 0 && a.get(i) >= a.get(i + 1)) i--;
        // Bước 2: Kiểm tra nếu không còn hoán vị nào lớn hơn
        if (i < 0) Collections.sort(a); // Đưa về hoán vị đầu tiên
        else {
            // Bước 3: Tìm vị trí đầu tiên từ cuối lớn hơn a[i]
            int j = n - 1;
            while (a.get(j) <= a.get(i)) j--;
            Collections.swap(a, i, j);// Hoán đổi a[i] và a[j]
            // Bước 4: Lật ngược đoạn từ i + 1 đến cuối mảng
            int l = i + 1, r = n - 1;
            while (l < r) {
                Collections.swap(a, l, r);
                l++;
                r--;
            }
        }
        String res = "";
        for(int x: a) res+=String.format("%d,", x);
        res = res.substring(0, res.length() - 1);
        System.out.println(res);
        // c. Gửi kết quả
        sv.submitData("B21DCCN564", "3Qe0Qb5w", res);
    }
}
```

### 8. Sinh tổ hợp chập k

**File gốc:** `RMI 2/code/SinhToHop.java`  |  **MSV:** `B21DCCN053`  |  **Mã đề:** `juC3u7C6`

Nhận `"<dãy>;<k>"`, sinh tuần tự mọi tổ hợp chập `k` chỉ số bằng thuật toán sinh kế tiếp rồi ánh xạ ra phần tử.

```java
package RMI.B21DCCN053;
import RMI.DataService;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.*;
public class SinhToHop {
    static int ok; 
    public static void kt(int a[], int k) {
        for (int i = 1; i <= k; i++) a[i] = i;
    }
    public static void sinh(int a[], int n, int k) {
        int i = k;
        while (i >= 1 && a[i] == n - k + i) i--;
        if (i == 0) {
            ok = 0;
        } else {
            a[i]++;
            for (int j = i + 1; j <= k; j++) a[j] = a[j - 1] + 1;
        }
    }
    public static void main(String[] args) throws Exception{
        Registry rg = LocateRegistry.getRegistry("203.162.10.109", 1099);
        DataService sv = (DataService) rg.lookup("RMIDataService");
        String s = (String)sv.requestData("B21DCCN053", "juC3u7C6");
        //String s = "2, 0, 5, 8, 1 ;3"; 
        System.out.println(s);
        int idx = s.indexOf(";");
        String s1 = s.substring(0, idx), s2 = s.substring(idx + 1);
        int k = Integer.parseInt(s2.trim());// Lấy số k
        // Lấy ra mảng và sắp xếp
        ArrayList<Integer> a = new ArrayList<>();
        s1 = s1.replace(",", " ");
        String[] tmp = s1.trim().split("\\s+");
        for (String x : tmp) a.add(Integer.parseInt(x));
        // Bắt đầu sinh tổ hợp. Khởi tạo
        int n = a.size();
        int[] genIdx = new int[k + 1];
        kt(genIdx, k);
        ok = 1;
        // Duyệt qua từng tổ hợp chỉ số
        ArrayList<ArrayList<Integer>> ans = new ArrayList<>();
        while (ok == 1) {
            ArrayList<Integer> tmp1 = new ArrayList<>();
            for (int i = 1; i <= k; i++) tmp1.add(a.get(genIdx[i] - 1));
            ans.add(tmp1);
            sinh(genIdx, n, k);
        }
        //c.
        System.out.println(ans);
        sv.submitData("B21DCCN053", "juC3u7C6", ans);
    }
}
```

### 9. Phương sai & độ lệch chuẩn

**File gốc:** `RMI 2/code/PhuongSai.java`  |  **MSV:** `B21DCCN016`  |  **Mã đề:** `uZMEY3Zg`

Tách dãy số thực, tính trung bình → phương sai → độ lệch chuẩn, gửi `"%.2f : %.2f"`.

```java
package RMI.B21DCCN016;
import java.rmi.*;
import java.rmi.registry.*;
import java.util.*;
import RMI.DataService;
public class PhuongSai {
    public static void main(String[] args) throws Exception {
        // a. Nhận dữ liệu
        Registry rg = LocateRegistry.getRegistry("203.162.10.109", 1099);
        DataService sv = (DataService) rg.lookup("RMIDataService");
        String s = (String) sv.requestData("B21DCCN016", "uZMEY3Zg");
        System.out.println(s);
        // b. Xử lý: Tìm danh sách các bộ ba số Pythagore
        ArrayList<Double> a = new ArrayList<>();
        s = s.replace(",", " ");
        String[] tmp = s.trim().split("\\s+");
        for (String x : tmp) a.add(Double.parseDouble(x));
        int n = a.size(); 
        double tong = 0, tongTmp = 0;
        for (double x : a) tong += x;
        double tbc = tong / (double) n;
        for (double x : a) tongTmp += (x - tbc) * (x - tbc);
        double pSai = tongTmp / n;  
        double doLechChuan = Math.sqrt(pSai);
        System.out.println(pSai);
        System.out.println(doLechChuan);
        // c. Gửi kết quả
        String res = String.format("%.2f : %.2f", pSai, doLechChuan);
        System.out.println(res);
        sv.submitData("B21DCCN016", "uZMEY3Zg", res);
    }
}
```

### B. CharacterService — 9 bài

### 10. La Mã → thập phân

**File gốc:** `RMI 2/code/ChuyenDoiLaMaThapPhan.java`  |  **MSV:** `B21DCCN015`  |  **Mã đề:** `0JaasIw6`

Duyệt từ phải sang trái: ký tự nhỏ hơn ký tự liền sau thì trừ, ngược lại cộng.

```java
package RMI.B21DCCN015;
import java.rmi.*;
import java.rmi.registry.*;
import java.util.*;
import RMI.CharacterService;
public class ChuyenDoiLaMaThapPhan {
    public static long trans(char c){
        if (c=='I') return 1;
        else if (c=='V') return 5;
        else if (c=='X') return 10;
        else if (c=='L') return 50;
        else if (c=='C') return 100;
        else if (c=='D') return 500;
        else return 1000;
    }
    public static long change(String s){
        long tong = 0;
        tong+= trans(s .charAt(s.length()-1));
        for(int i = s.length() - 2;i>=0;i--){
            if(trans(s.charAt(i+ 1))>trans(s.charAt(i))) tong-=trans(s.charAt(i));
            else tong+=trans(s.charAt(i));
        }
        return tong;
    }
    public static void main(String[] args) throws Exception{
        //a.
        Registry rg = LocateRegistry.getRegistry("203.162.10.109", 1099);
        CharacterService sv = (CharacterService) rg.lookup("RMICharacterService");
        String s = sv.requestCharacter("B21DCCN015", "0JaasIw6");
        System.out.println(s);
        //c. Gửi
        System.out.println(change(s));
        sv.submitCharacter("B21DCCN015", "0JaasIw6", String.valueOf(change(s)));
    }
}
```

### 11. Thập phân → La Mã

**File gốc:** `RMI 2/code/ChuyenDoiThapPhanLaMa.java`  |  **MSV:** `B21DCCN032`  |  **Mã đề:** `ADu6zRYE`

Tham lam trên 2 mảng song song `{1000, 900, 500, …}` và `{"M", "CM", "D", …}`.

```java
package RMI.B21DCCN032;
import RMI.CharacterService;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
public class ChuyenDoiThapPhanLaMa {
    public static void main(String[] args)throws Exception{
        Registry rg = LocateRegistry.getRegistry("203.162.10.109", 1099);
        CharacterService sv = (CharacterService) rg.lookup("RMICharacterService");
        String s = sv.requestCharacter("B21DCCN032", "ADu6zRYE");
        System.out.println(s);
        //b.
        String rm = "";
        int dec = Integer.parseInt(s);
        int[] tp = {1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};//thập phân
        String[] lm = {"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"};// la mã
        for(int i = 0;i<tp.length;i++){
            while(dec >=tp[i]){
                rm+=lm[i];
                dec-=tp[i];
            }
        }
        System.out.println(rm);     
        //c.
        sv.submitCharacter("B21DCCN032", "ADu6zRYE", rm);
    }
}
```

### 12. Đếm số lần xuất hiện (dạng nén)

**File gốc:** `RMI 2/code/DemSoLanXH1.java`  |  **MSV:** `B21DCCN564`  |  **Mã đề:** `U5BEBBOW`

Đếm tần suất bằng mảng `cnt[256]`, xuất `<ký tự><số lần>` theo thứ tự gặp đầu tiên.

```java
package RMI.B21DCCN564;
import java.rmi.*;
import java.rmi.registry.*;
import java.util.*;
import RMI.CharacterService;
public class DemSoLanXH1 {
    public static void main(String[] args) throws Exception {
        // a. Nhận chuỗi từ server
        Registry rg = LocateRegistry.getRegistry("203.162.10.109", 1099);
        CharacterService sv = (CharacterService) rg.lookup("RMICharacterService");
        String s = sv.requestCharacter("B21DCCN564", "U5BEBBOW");
        System.out.println(s);
        // b. Xử lý xâu
        String res = "";
        int[] cnt = new int[256]; 
        for (char x : s.toCharArray()) cnt[x]++;
        for(char x: s.toCharArray()){
            if(cnt[x] > 0){
                res+=String.format("%c%d", x, cnt[x]);
                cnt[x] = 0;
            }
        }
        System.out.println(res);
        // c. Gửi kết quả lại server
        sv.submitCharacter("B21DCCN564", "U5BEBBOW", res);
    }
}
```

### 13. Đếm số lần xuất hiện (dạng JSON)

**File gốc:** `RMI 2/code/DemSoLanXH2.java`  |  **MSV:** `B21DCCN012`  |  **Mã đề:** `ctRfIejL`

Giống bài trên nhưng định dạng ra `{"a": 3, "b": 2}`.

```java
package RMI.B21DCCN012;
import java.rmi.*;
import java.rmi.registry.*;
import java.util.*;
import RMI.CharacterService;
public class DemSoLanXH2 {
    public static void main(String[] args) throws Exception {
        // a. Nhận chuỗi từ server
        Registry rg = LocateRegistry.getRegistry("203.162.10.109", 1099);
        CharacterService sv = (CharacterService) rg.lookup("RMICharacterService");
        String s = sv.requestCharacter("B21DCCN012", "ctRfIejL");
        System.out.println(s);
        int[] cnt = new int[256]; 
        for (char x : s.toCharArray()) cnt[x]++;
        String res = "";
        boolean first = true;
        for (char x : s.toCharArray()) {
            if (cnt[x] > 0) {
                if (!first) res+=", ";
                res+=String.format("\"%c\": %d", x, cnt[x]); 
                cnt[x] = 0; 
                first = false;
            }
        }
        res = "{" + res + "}";
        System.out.println(res);
        // c. Gửi kết quả lại server
        sv.submitCharacter("B21DCCN012", "ctRfIejL", res);
    }
}
```

### 14. Mã hóa Base64

**File gốc:** `RMI 2/code/MaHoaBase64.java`  |  **MSV:** `B21DCCN029`  |  **Mã đề:** `psd4Jmnt`

`Base64.getEncoder().encode(s.getBytes())` rồi trả về xâu.

```java
package RMI.B21DCCN029;
import RMI.CharacterService;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Base64;
public class MaHoaBase64 {
    public static void main(String[] args) throws Exception{
        Registry rg = LocateRegistry.getRegistry("203.162.10.109", 1099);
        CharacterService sv = (CharacterService) rg.lookup("RMICharacterService");
        String s = sv.requestCharacter("B21DCCN029", "psd4Jmnt");
        System.out.println(s);
        //
        byte []tmp = Base64.getEncoder().encode(s.getBytes());
        String ans = new String(tmp);
        System.out.println(ans);
        //
        sv.submitCharacter("B21DCCN029", "psd4Jmnt", ans);
    }
}
```

### 15. Mã hóa Caesar (xâu)

**File gốc:** `RMI 2/code/MaHoaCaesar1.java`  |  **MSV:** `B21DCCN022`  |  **Mã đề:** `j4rStb2a`

Độ dịch = `độ dài xâu % 7`, dịch **lùi**, giữ nguyên hoa/thường bằng `base = 'A'` hoặc `'a'`.

```java
package RMI.B21DCCN022;
import java.rmi.*;
import java.rmi.registry.*;
import java.util.*;
import RMI.CharacterService;
public class MaHoaCaesar1 {
    public static void main(String[] args) throws Exception{
        Registry rg = LocateRegistry.getRegistry("203.162.10.109", 1099);
        CharacterService sv = (CharacterService) rg.lookup("RMICharacterService");
        String s = sv.requestCharacter("B21DCCN022", "j4rStb2a");
        System.out.println(s);
        //b.
        String ans = "";
        int dich = s.length()%7;
        for(char x: s.toCharArray()){
            char base = Character.isUpperCase(x) ? 'A' : 'a';
            x = (char) ((x - base - dich + 26) % 26 + base);
            ans+=x;
        }
        System.out.println(ans);
        //c.
        sv.submitCharacter("B21DCCN022", "j4rStb2a", ans);
    }
}
```

### 16. Mã hóa Vigenère

**File gốc:** `RMI 2/code/MaHoaVigen.java`  |  **MSV:** `B21DCCN021`  |  **Mã đề:** `Y7YMXHs4`

Nhận `"<khóa>;<văn bản>"`, cộng modulo 26 ký tự văn bản với ký tự khóa lặp vòng.

```java
package RMI.B21DCCN021;
import java.util.*;
import java.rmi.*;
import java.rmi.registry.*;
import RMI.CharacterService;
public class MaHoaVigen {
    public static void main(String[] args) throws Exception{
        Registry rg = LocateRegistry.getRegistry("203.162.10.109", 1099);
        CharacterService sv = (CharacterService) rg.lookup("RMICharacterService");
        String s = sv.requestCharacter("B21DCCN021", "Y7YMXHs4");
        System.out.println(s);
        int idx = s.indexOf(";");
        String keyW = s.substring(0, idx), text = s.substring(idx + 1), ans = "";
        for(int i = 0;i<text.length();i++){
            char x = text.charAt(i), y = keyW.charAt(i % keyW.length());
            char z;
            if (Character.isUpperCase(x)) z = (char) ((x - 'A' + y - 'A') % 26 + 'A');
            else z = (char) ((x - 'a' + y - 'a') % 26 + 'a');
            ans+=z;
        }
        System.out.println(ans);
        sv.submitCharacter("B21DCCN021", "Y7YMXHs4", ans);
    } 
}
```

### 17. Mã hóa URL

**File gốc:** `RMI 2/code/MaHoaURL.java`  |  **MSV:** `B21DCCN053`  |  **Mã đề:** `KkihaRAB`

`URLEncoder.encode(s, "UTF-8")`.

```java
package RMI.B21DCCN053;
import java.rmi.*;
import java.rmi.registry.*;
import java.util.*;
import java.net.URLEncoder;
import RMI.CharacterService;
public class MaHoaURL {
    public static void main(String[] args) throws Exception{
        Registry rg = LocateRegistry.getRegistry("203.162.10.109", 1099);
        CharacterService sv = (CharacterService) rg.lookup("RMICharacterService");
        String s = sv.requestCharacter("B21DCCN053", "KkihaRAB");
        System.out.println(s);
        //b.
        String ans = URLEncoder.encode(s, "UTF-8");
        System.out.println(ans);
        //c.
        sv.submitCharacter("B21DCCN053", "KkihaRAB", ans);
    }
}
//Sửa đề xong thì chịu không biết AC kiểu gì??
```

### 18. Xử lý văn bản — tách chẵn/lẻ

**File gốc:** `RMI 2/code/XuLyVanBan.java`  |  **MSV:** `B21DCCN319`  |  **Mã đề:** `NFldNPp6`

Bỏ `" { }`, tách theo dấu phẩy, gom phần tử chỉ số chẵn và lẻ thành `"<chẵn>; <lẻ>"`.

```java
package RMI.B21DCCN319;
import java.rmi.*;
import java.rmi.registry.*;
import java.util.*;
import RMI.CharacterService;
public class XuLyVanBan {
    public static void main(String[] args) throws Exception {
        // a. Nhận chuỗi từ server
        Registry rg = LocateRegistry.getRegistry("203.162.10.109", 1099);
        CharacterService sv = (CharacterService) rg.lookup("RMICharacterService");
        String s = sv.requestCharacter("B21DCCN319", "NFldNPp6");
        System.out.println(s);
        // b. Xử lý xâu
        s = s.replace("\"", "");  s = s.replace("{", "");  s = s.replace("}", "");   
        String[] tmp = s.trim().split(",");// Tách chuỗi thành các cặp key-value
        String chan = "", le = "";
        for (int i = 0; i < tmp.length; i++) {
            tmp[i] = tmp[i].trim(); 
            if (i % 2 == 0) {
                if (chan.length() > 0) chan+=", ";
                chan+=tmp[i];
            } else {
                if (le.length() > 0) le+=", ";
                le+=tmp[i];
            }
        }
        String res = chan + "; " + le;
        System.out.println(res);
        // c. Gửi kết quả lại server
        sv.submitCharacter("B21DCCN319", "NFldNPp6", res);
    }
}
```

### C. ByteService — 9 bài

### 19. Giải mã Base64

**File gốc:** `RMI 2/code/GiaiMaBase64.java`  |  **MSV:** `B21DCCN015`  |  **Mã đề:** `oeJljCIf`

`byte[]` → `String` → `Base64.getDecoder().decode(...)` → gửi lại `byte[]`.

```java
package RMI.B21DCCN015;
import RMI.ByteService;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Base64;
public class GiaiMaBase64 {
    public static void main(String[] args) throws Exception{
        // a. Nhận dữ liệu từ server
        Registry rg = LocateRegistry.getRegistry("203.162.10.109", 1099);
        ByteService sv = (ByteService) rg.lookup("RMIByteService");
        byte[] a = sv.requestData("B21DCCN015", "oeJljCIf");
        // b. Giải mã 
        String s = new String(a);  //Byte -->String
        System.out.println(s);
        byte[] ans = Base64.getDecoder().decode(s);  // Giải mã Base64
        for (byte x: ans) System.out.print(x + " ");
        System.out.println();
        // c. 
        sv.submitData("B21DCCN015", "oeJljCIf", ans);
    }
}
```

### 20. Mã hóa Hexa

**File gốc:** `RMI 2/code/MaHoaHexa.java`  |  **MSV:** `B21DCCN032`  |  **Mã đề:** `pK0IZNnt`

Mỗi byte → `String.format("%02x", x & 0xFF)`, ghép thành xâu rồi `getBytes()`.

```java
package RMI.B21DCCN032;
import java.rmi.*;
import java.rmi.registry.*;
import RMI.ByteService;
public class MaHoaHexa {
    public static void main(String[] args) throws Exception {
        // a. Nhận dữ liệu từ server
        Registry rg = LocateRegistry.getRegistry("203.162.10.109", 1099);
        ByteService sv = (ByteService) rg.lookup("RMIByteService");
        byte[] a = sv.requestData("B21DCCN032", "pK0IZNnt");
        for (byte x : a) System.out.print(x + " ");
        System.out.println();
        // b. Chuyển đổi mảng byte thành chuỗi hexa
        String res = "";
        for (byte x : a) res+=String.format("%02x", x & 0xFF);
        System.out.println(res);
        byte[] ans = res.toString().getBytes();
        sv.submitData("B21DCCN032", "pK0IZNnt", ans);
    }
}
```

### 21. Mã hóa Caesar (mảng byte)

**File gốc:** `RMI 2/code/MaHoaCaesar2.java`  |  **MSV:** `B21DCCN028`  |  **Mã đề:** `i0EVI2TB`

Cộng mỗi byte với độ dịch = độ dài mảng.

```java
package RMI.B21DCCN028;
import RMI.ByteService;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
public class MaHoaCaesar2 {
    public static void main(String[] args) throws Exception{
        Registry rg = LocateRegistry.getRegistry("203.162.10.109", 1099);
        ByteService sv = (ByteService) rg.lookup("RMIByteService");
        byte[] a = sv.requestData("B21DCCN028", "i0EVI2TB");
        for(byte x: a) System.out.print(x + " ");
        System.out.println("");
        int doDich = a.length;
        for (int i = 0; i < a.length; i++) a[i]+=doDich;
        for(byte x: a) System.out.print(x + " ");
        //c.
        sv.submitData("B21DCCN028", "i0EVI2TB", a);
    }
}
```

### 22. Mã hóa XOR với khóa "PTIT"

**File gốc:** `RMI 2/code/PhepXOR2.java`  |  **MSV:** `B21DCCN012`  |  **Mã đề:** `4BraNTI5`

`maHoa[i] = a[i] ^ key[i % key.length]` với `key = "PTIT".getBytes()`.

```java
import java.rmi.*;
import java.rmi.registry.*;
import java.util.*;
import RMI.ByteService;
public class PhepXOR2 {
    public static void main(String[] args) throws Exception {
        // a. Nhận dữ liệu từ server
        Registry rg = LocateRegistry.getRegistry("203.162.10.109", 1099);
        ByteService sv = (ByteService) rg.lookup("RMIByteService");
        byte[] a = sv.requestData("B21DCCN012", "4BraNTI5");
        for(byte x: a) System.out.print(x + " ");
        System.out.println();
        //b. Mã hoá
        String tmp = "PTIT";
        byte[] tmpB = tmp.getBytes(); // Chuyển khóa thành mảng byte
        byte[] maHoa = new byte[a.length];
        for(int i = 0;i<a.length;i++) maHoa[i] = (byte) (a[i] ^ tmpB[i % tmpB.length]);
        for(byte x: maHoa) System.out.print(x + " ");
        //c. Gửi
        sv.submitData("B21DCCN012", "4BraNTI5", maHoa);
    }
}
```

### 23. Nén RLE

**File gốc:** `RMI 2/code/NenRLE.java`  |  **MSV:** `B21DCCN036`  |  **Mã đề:** `2uG0lQGi`

Duyệt mảng, gom các byte liên tiếp giống nhau thành cặp `(giá trị, số lần)`.

```java
package RMI.B21DCCN036;
import java.util.*;
import java.rmi.*;
import java.rmi.registry.*;
import RMI.ByteService;
public class NenRLE {
    public static void main(String[] args) throws Exception{
        Registry rg = LocateRegistry.getRegistry("203.162.10.109", 1099);
        ByteService sv = (ByteService) rg.lookup("RMIByteService");
        byte[] a = sv.requestData("B21DCCN036", "2uG0lQGi");
        for (byte x : a) System.out.print(x + " ");
        System.out.println();
        // b. 
        int cnt = 1;
        ArrayList<Byte>res = new ArrayList<>();
        for(int i = 1;i<a.length;i++){
            if(a[i] == a[i - 1]) cnt++;
            else{
                res.add(a[i - 1]); res.add((byte)cnt);
                cnt = 1;
            }
        }
        res.add(a[a.length - 1]); res.add((byte)cnt);
        //Cóp sang mảng
        byte []ans = new byte[res.size()];
        int idx = 0;
        for(byte x: res) ans[idx++] = x;
        for(byte x: ans) System.out.print(x + " ");
        sv.submitData("B21DCCN036", "2uG0lQGi", ans);        
    }
}
```

### 24. Sắp xếp chẵn trước lẻ sau

**File gốc:** `RMI 2/code/SapXepChanLe.java`  |  **MSV:** `B21DCCN029`  |  **Mã đề:** `A7hytb1V`

Duyệt 2 lượt: lượt 1 lấy byte chẵn, lượt 2 lấy byte lẻ, giữ nguyên thứ tự tương đối.

```java
package RMI.B21DCCN029;
import RMI.ByteService;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
public class SapXepChanLe {
    public static void main(String[] args) throws Exception{
        //a.
        Registry rg = LocateRegistry.getRegistry("203.162.10.109", 1099);
        ByteService sv = (ByteService) rg.lookup("RMIByteService");
        byte[] a = sv.requestData("B21DCCN029", "A7hytb1V");
        for(byte x: a) System.out.print(x + " ");
        System.out.println("");
        //b. sx
        byte []res = new byte[a.length];
        int idx = 0;
        for(byte x: a){
            if(x % 2==0)  res[idx++] = x;
        }
        for(byte x: a){
            if(x % 2==1)  res[idx++] = x;
        }
        for(byte x: res) System.out.print(x + " ");
        //c.
        sv.submitData("B21DCCN028", "A7hytb1V", res);
    }
}
```

### 25. Phần tử xuất hiện nhiều nhất

**File gốc:** `RMI 2/code/XHMax.java`  |  **MSV:** `B21DCCN319`  |  **Mã đề:** `1mPMIkGJ`

Đếm bằng `cnt[128]`, trả về `{giá trị, số lần}`.

```java
package RMI.B21DCCN319;
import java.rmi.*;
import java.rmi.registry.*;
import java.util.*;
import RMI.ByteService;
public class XHMax {
    public static void main(String[] args) throws Exception {
        // a. Nhận dữ liệu từ server
        Registry rg = LocateRegistry.getRegistry("203.162.10.109", 1099);
        ByteService sv = (ByteService) rg.lookup("RMIByteService");
        byte[] a = sv.requestData("B21DCCN319", "1mPMIkGJ");
        for(byte x: a) System.out.print(x + " ");
        System.out.println("");
        //b. Đếm
        int[] cnt = new int[128]; 
        for (byte x : a) cnt[x]++;
        byte ptuMax = a[0];
        int slMax = cnt[ptuMax];
        for (byte x : a) {
            if (cnt[x] > slMax) {
                ptuMax = x;
                slMax = cnt[x];
            }
        }
        System.out.println(ptuMax + " " + slMax);
        // c. Gửi
        byte[] res = {ptuMax, (byte) slMax};
        sv.submitData("B21DCCN319", "1mPMIkGJ", res);
    }
}
```

### 26. Phần tử xuất hiện ít nhất

**File gốc:** `RMI 2/code/XHMin.java`  |  **MSV:** `B21DCCN564`  |  **Mã đề:** `L7A2NPQU`

Đối ngẫu của bài trên — tìm tần suất nhỏ nhất.

```java
package RMI.B21DCCN564;
import java.rmi.*;
import java.rmi.registry.*;
import java.util.*;
import RMI.ByteService;
public class XHMin {
    public static void main(String[] args) throws Exception {
        // a. Nhận dữ liệu từ server
        Registry rg = LocateRegistry.getRegistry("203.162.10.109", 1099);
        ByteService sv = (ByteService) rg.lookup("RMIByteService");
        byte[] a = sv.requestData("B21DCCN564", "L7A2NPQU");
        for(byte x: a) System.out.print(x + " ");
        System.out.println("");
        //b. Đếm
        int[] cnt = new int[10005]; 
        for (byte x : a) cnt[x]++;
        byte ptuMin = a[0];
        int slMin = cnt[a[0]];
        for (byte x : a) {
            if (cnt[x] < slMin) {
                ptuMin = x;
                slMin = cnt[x];
            }
        }
        System.out.println(ptuMin + " " + slMin);
        // c. Gửi
        byte[] res = {ptuMin, (byte)slMin};
        sv.submitData("B21DCCN564", "L7A2NPQU", res);
    }
}
```

### 27. Phần tử lớn thứ K

**File gốc:** `RMI 2/code/LonThuK.java`  |  **MSV:** `B21DCCN066`  |  **Mã đề:** `uIKHCTWG`

Phần tử cuối mảng là `k`. Sao mảng, sắp xếp, lấy `a[n-k]` rồi dò vị trí gốc → gửi `{giá trị, vị trí 1-based}`.

```java
package RMI.B21DCCN066;
import java.rmi.*;
import java.rmi.registry.*;
import java.util.*;
import RMI.ByteService;
public class LonThuK {
    public static void main(String[] args) throws Exception{
        Registry rg = LocateRegistry.getRegistry("203.162.10.109", 1099);
        ByteService sv = (ByteService) rg.lookup("RMIByteService");
        byte[] a = sv.requestData("B21DCCN066", "uIKHCTWG");
        for(byte x: a) System.out.print(x + " ");  
        System.out.println();
        //b.
        byte []b = Arrays.copyOf(a, a.length);
        int k = a[a.length - 1], pos = 0;
        Arrays.sort(a);
        for(int i = 0;i<b.length;i++){
            if(b[i]==a[a.length - k]){
                pos = i;
                break;
            }
        }
        byte []ans = {(byte)a[a.length - k], (byte)(pos + 1)};
        for(byte x: ans) System.out.print(x + " ");
        //c.
        sv.submitData("B21DCCN066", "uIKHCTWG", ans);
    }
}
```

### D. ObjectService — 8 bài

### 28. Chuẩn hóa sản phẩm — Product

**File gốc:** `RMI 2/code/XuLySanPham1.java`  |  **MSV:** `B21DCCN319`  |  **Mã đề:** `dx3nt4Ij`

Viết hoa `code`, đặt `exportPrice = importPrice * 1.2`.

```java
package RMI.B21DCCN319;
import java.rmi.*;
import java.rmi.registry.*;
import RMI.ObjectService;
import RMI.Product;
public class XuLySanPham1 {
    public static void main(String[] args) throws Exception {
        //a. Nhận sản phẩm từ server
        Registry rg = LocateRegistry.getRegistry("203.162.10.109", 1099);
        ObjectService sv = (ObjectService) rg.lookup("RMIObjectService");
        Product product = (Product) sv.requestObject("B21DCCN319", "dx3nt4Ij");
        System.out.println(product);
        // b. Thực hiện chuẩn hóa sản phẩm:
        product.setCode(product.getCode().toUpperCase());// Chuyển mã sản phẩm thành in hoa
        product.setExportPrice(product.getImportPrice() * 1.2f);
        System.out.println("Normalized product: " + product);
        // c. Triệu gọi phương thức submitObject để gửi đối tượng đã chuẩn hóa trở lại server
        sv.submitObject("B21DCCN319", "dx3nt4Ij", product);
    }
}
```

### 29. Chuẩn hóa sản phẩm — ProductX

**File gốc:** `RMI 2/code/XuLySanPham2.java`  |  **MSV:** `B21DCCN564`  |  **Mã đề:** `PY43T66m`

`discount` = tổng các chữ số xuất hiện trong `discountCode`.

```java
package RMI.B21DCCN564;
import java.rmi.*;
import java.rmi.registry.*;
import RMI.ObjectService;
import RMI.ProductX;
public class XuLySanPham2 {
    public static void main(String[] args) throws Exception {
        //a. Nhận sản phẩm từ server
        Registry rg = LocateRegistry.getRegistry("203.162.10.109", 1099);
        ObjectService sv = (ObjectService) rg.lookup("RMIObjectService");
        ProductX product = (ProductX) sv.requestObject("B21DCCN564", "PY43T66m");
        System.out.println(product);
        // b. Thực hiện chuẩn hóa sản phẩm:
        int tong = 0;
        for(char x: product.getDiscountCode().toCharArray()){
            if(Character.isDigit(x)) tong+=Character.getNumericValue(x);
        }
        product.setDiscount(tong);
        // c. Triệu gọi phương thức submitObject để gửi đối tượng đã chuẩn hóa trở lại server
        System.out.println(product);
        sv.submitObject("B21DCCN564", "PY43T66m", product);
    }
}
```

### 30. Tính lương nhân viên — Employee

**File gốc:** `RMI 2/code/QuanLyNhanVien.java`  |  **MSV:** `B21DCCN038`  |  **Mã đề:** `7fSWnlHB`

`factor = (số năm KN + tổng chữ số + số ước) / 100`; `finalSalary = baseSalary * (1 + factor)`.

```java
package RMI.B21DCCN038;
import java.rmi.*;
import java.rmi.registry.*;
import RMI.ObjectService;
import RMI.Employee;
public class QuanLyNhanVien {
    public static void main(String[] args) throws Exception{
        //a.
        Registry rg = LocateRegistry.getRegistry("203.162.10.109", 1099);
        ObjectService sv = (ObjectService) rg.lookup("RMIObjectService");
        Employee employee = (Employee) sv.requestObject("B21DCCN038", "7fSWnlHB");
        System.out.println(employee);
        //b.tổng cs
        int tongCS = 0, x = employee.getExperienceYears(), y = employee.getExperienceYears();
        while(x>0){
            tongCS+=x%10;
            x/=10;
        }
        //tổng ước
        int soUoc = 0;
        for(int i = 1;i<=y;i++){
            if(y%i==0) soUoc++;
        }
        //factor
        double factor = (double)(employee.getExperienceYears() + tongCS + soUoc)/100.0;
        double Final = (employee.getBaseSalary()) * (1 + factor);
        //
        employee.setFinalSalary(Final);
        System.out.println(employee);
        //c.
        sv.submitObject("B21DCCN038", "7fSWnlHB", employee);
    }
}
```

### 31. Sinh mã sinh viên — Student

**File gốc:** `RMI 2/code/QuanLySinhVien.java`  |  **MSV:** `B21DCCN023`  |  **Mã đề:** `lNV6xzmk`

Chuẩn hóa tên (chữ cái đầu hoa, họ cuối in hoa toàn bộ), mã = `B<2 số năm> + <TÊN> + _ + <chữ cái đầu các từ còn lại>`.

```java
package RMI.B21DCCN023;
import java.util.*;
import java.rmi.*;
import java.rmi.registry.*;
import RMI.ObjectService;
import RMI.Student;
public class QuanLySinhVien {
    public static String chuanhoa(String s) {
        return Character.toUpperCase(s.charAt(0)) + s.substring(1).toLowerCase();
    }
    public static String chuanhoa2(String s){
        String []tmp = s.trim().split("\\s+");
        String res = "";
        for(int i = 0;i<tmp.length - 1;i++) res+=chuanhoa(tmp[i]) + " ";
        res+=tmp[tmp.length - 1].toUpperCase();
        return res;
    }
    public static void main(String[] args) throws Exception{
        Registry rg = LocateRegistry.getRegistry("203.162.10.109", 1099);
        ObjectService sv = (ObjectService) rg.lookup("RMIObjectService");
        Student student = (Student) sv.requestObject("B21DCCN023", "lNV6xzmk");
        System.out.println(student);
        student.setName(chuanhoa2(student.getName()));
        String code = String.format("B%d", student.getEnrollmentYear()%100);
        String []tmp = student.getName().split("\\s+");
        code+=tmp[tmp.length - 1].toUpperCase() + "_";
        for(int i = 0;i<tmp.length - 1;i++) code+=Character.toUpperCase(tmp[i].charAt(0));
        student.setCode(code);
        System.out.println(student);
        //c.
        sv.submitObject("B21DCCN023", "lNV6xzmk", student);
    }
}
```

### 32. Sinh mã sách — BookX

**File gốc:** `RMI 2/code/QuanLyThuVien2.java`  |  **MSV:** `B21DCCN012`  |  **Mã đề:** `CoWosBho`

Mã = chữ đầu tên tác giả + chữ cuối họ + `%02d` năm XB + độ dài thể loại + độ dài tiêu đề `% 10`.

```java
package RMI.B21DCCN012;
import java.rmi.*;
import java.rmi.registry.*;
import RMI.ObjectService;
import RMI.BookX;
public class QuanLyThuVien2 {
    public static void main(String[] args) throws Exception {
        //a. Nhận sản phẩm từ server
        Registry rg = LocateRegistry.getRegistry("203.162.10.109", 1099);
        ObjectService sv = (ObjectService) rg.lookup("RMIObjectService");
        BookX book = (BookX) sv.requestObject("B21DCCN012", "CoWosBho");
        System.out.println(book);
        //Tạo mã
        String code = "";
        String[] tmp = book.getAuthor().split(" ");
        code+=tmp[0].charAt(0);code+=tmp[tmp.length - 1].charAt(tmp[tmp.length - 1].length() - 1);
        code+=String.format("%02d%d%d", book.getYearPublished()%100, 
                book.getGenre().trim().length(), book.getTitle().length()%10);
        book.setCode(code);
        // c. 
        sv.submitObject("B21DCCN012", "CoWosBho", book);
    }
}
```

### 33. Sinh mã vé — Ticket

**File gốc:** `RMI 2/code/QuanLySuKien.java`  |  **MSV:** `B21DCCN048`  |  **Mã đề:** `Uct8bABt`

Mã = chữ đầu + chữ cuối tên sự kiện (in hoa) + `MMdd` ngày bán + chữ số lớn nhất chưa dùng + chữ số nhỏ nhất chưa dùng.

```java
package RMI.B21DCCN048;
import java.rmi.*;
import java.rmi.registry.*;
import RMI.ObjectService;
import RMI.Ticket;
import java.util.*;
public class QuanLySuKien {
    public static void main(String[] args) throws Exception{
        Registry rg = LocateRegistry.getRegistry("203.162.10.109", 1099);
        ObjectService sv = (ObjectService) rg.lookup("RMIObjectService");
        Ticket ticket = (Ticket) sv.requestObject("B21DCCN048", "Uct8bABt");
        //Ticket ticket = new Ticket(1, "Charity Concert", "15/06/2024");
        System.out.println(ticket);
        //Lấy tên
        String s = ticket.getEventName().toUpperCase();
        String res = "";
        res+=String.format("%c%c", Character.toUpperCase(s.charAt(0)), (char)Character.toUpperCase(s.charAt(s.length() - 1)));
        //Lấy ngày sinh
        String s1 = ticket.getSaleDate();
        s1 = s1.replace("/", " ");
        String []tmp = s1.trim().split("\\s+");
        res+=tmp[1] + tmp[0];
        //Lấy 2 chữ số
        Set<Integer>si = new HashSet<>();
        for(char x: s1.toCharArray()){
            if(Character.isDigit(x)) si.add(x - '0');
        }
        for(int i = 9;i >= 0;i--){
            if(!si.contains(i)){
                res+=i;
                break;
            }
        }
        for(int i = 0;i<=9;i++){
            if(!si.contains(i)){
                res+=i;
                break;
            }
        }
        ticket.setTicketCode(res);
        System.out.println(ticket);
        //c.
        sv.submitObject("B21DCCN048", "Uct8bABt", ticket);
    }
}
```

### 34. Sinh mã sự kiện — Event

**File gốc:** `RMI 2/code/ToChucSuKien.java`  |  **MSV:** `B21DCCN029`  |  **Mã đề:** `FKrGvwLM`

Cỡ sự kiện (`L` ≥ 1000, `M` 500–999, còn lại `S`) + chữ đầu/chữ cuối tên + `ddMM` ngày tổ chức.

```java
package RMI.B21DCCN029;
import java.rmi.*;
import java.rmi.registry.*;
import RMI.ObjectService;
import RMI.Event;
public class ToChucSuKien {
    public static void main(String[] args) throws Exception{
        //a.
        Registry rg = LocateRegistry.getRegistry("203.162.10.109", 1099);
        ObjectService sv = (ObjectService) rg.lookup("RMIObjectService");
        Event event = (Event) sv.requestObject("B21DCCN029", "FKrGvwLM");
        System.out.println(event);
        //b.
        String ans = "";
        int x = event.getExpectedAttendance();
        //
        if(x>=1000) ans = "L";
        else if (x>=500 && x<=999) ans = "M";
        else ans = "S";
        //
        String []tmp = event.getEventName().trim().split("\\s+");
        ans+=Character.toUpperCase(tmp[0].charAt(0));
        ans+=Character.toUpperCase(tmp[tmp.length - 1].charAt(tmp[tmp.length - 1].length() - 1));
        //
        String tmp1 = event.getEventDate();
        tmp1 = tmp1.replace("-", " ");
        String []tmp2 = tmp1.trim().split("\\s+");
        ans+=tmp2[2] + tmp2[1];
        event.setEventCode(ans);
        //c.
        System.out.println(event);
        sv.submitObject("B21DCCN029", "FKrGvwLM", event);
    } 
}
```

### 35. Sinh mã đơn hàng — Order

**File gốc:** `RMI 2/code/TDMT.java`  |  **MSV:** `B21DCCN021`  |  **Mã đề:** `vLJWvWpf`

Mã = 2 ký tự đầu `shippingType` (in hoa) + 3 ký tự cuối `customerCode` + `ddMM` ngày đặt.

```java
package RMI.B21DCCN021;
import RMI.Order;
import java.rmi.*;
import java.rmi.registry.*;
import RMI.ObjectService;
public class TDMT {
    public static void main(String[] args) throws Exception{
        Registry rg = LocateRegistry.getRegistry("203.162.10.109", 1099);
        ObjectService sv = (ObjectService) rg.lookup("RMIObjectService");
        Order order = (Order) sv.requestObject("B21DCCN021", "vLJWvWpf");
        System.out.println(order);
        //b.
        String x = order.getShippingType().substring(0, 2).toUpperCase(); // Hai ký tự đầu của shippingType
        String y = order.getCustomerCode().substring(order.getCustomerCode().length() - 3); // Ba ký tự cuối của customerCode
        String z = order.getOrderDate().substring(8, 10) + order.getOrderDate().substring(5, 7); // ddMM từ orderDate
        String orderCode = x + y + z;
        order.setOrderCode(orderCode);
        //c
        System.out.println(order);
        sv.submitObject("B21DCCN021", "vLJWvWpf", order);
    }
}
```

---

## Phần III — 28 bài Web Service

### A. DataService — 11 bài

### 1. Tổng các số

**File gốc:** `WebService/B21DCCN082/TongCacSo.java`  |  **MSV:** `B21DCCN082`  |  **Mã đề:** `hnVAHv3I`

Cộng dồn `List<Integer>` rồi `submitDataInt`.

```java
package WebService.B21DCCN082;
import vn.medianews.*;
import java.util.*;
public class TongCacSo {
    public static void main(String[] args) throws Exception{
        String msv = "B21DCCN082", qCode = "hnVAHv3I"; 
        DataService_Service service = new DataService_Service();
        DataService port = service.getDataServicePort();
        List<Integer>a = port.getData(msv, qCode);
        System.out.println(a);
        int tong = 0;
        for(int x: a) tong+=x;
        System.out.println(tong);
        port.submitDataInt(msv, qCode, tong);
    }
}
```

### 2. Liệt kê ước số

**File gốc:** `WebService/B21DCCN004/LietKeUoc.java`  |  **MSV:** `B21DCCN004`  |  **Mã đề:** `nhFjYg0F`

Nhận 1 số qua `getDataDouble`, liệt kê ước, chèn số lượng ước vào đầu danh sách.

```java
package WebService.B21DCCN004;
import vn.medianews.*;
import java.util.*;
public class LietKeUoc {
    public static void main(String[] args) throws Exception{
        String msv = "B21DCCN004", qCode = "nhFjYg0F"; 
        DataService_Service service = new DataService_Service();
        DataService port = service.getDataServicePort();
        int n = (int)port.getDataDouble(msv, qCode);
        System.out.println(n);
        List<Integer>ans = new java.util.ArrayList<>();
        for(int i = 1;i<=n;i++){
            if(n%i==0) ans.add(i);
        }
        ans.add(0, ans.size());
        System.out.println(ans);
        port.submitDataIntArray(msv, qCode, ans);
    }
}
```

### 3. Phân tích thừa số nguyên tố

**File gốc:** `WebService/B21DCCN001/PTichTSNT.java`  |  **MSV:** `B21DCCN001`  |  **Mã đề:** `TwZpbqUg`

Phân tích từng số trong danh sách, mỗi kết quả là một xâu `"2, 2, 3"`.

```java
package WebService.B21DCCN001;
import vn.medianews.*;
import java.util.*;
public class PTichTSNT {
    public static void main(String[] args) throws Exception {
        String msv = "B21DCCN001", qCode = "TwZpbqUg"; 
        DataService_Service service = new DataService_Service();
        DataService port = service.getDataServicePort();
        List<Integer> a = port.getData(msv, qCode);
        System.out.println(a);
        List<String>ans = new java.util.ArrayList<>();
        for(int x: a){
            String tmp = "";
            for(int i = 2;i*i<=x;i++){
                while(x%i==0){
                    x/=i;
                    tmp+=String.format("%d, ", i);
                }
            }
            if(x > 1) tmp+=String.format("%d, ", x);
            tmp = tmp.trim();
            tmp = tmp.substring(0, tmp.length() - 1);
            ans.add(tmp);
            System.out.println(tmp);
        }
        port.submitDataStringArray(msv, qCode, ans);
    }
}
```

### 4. Đếm số lần xuất hiện

**File gốc:** `WebService/B21DCCN002/DemSoLanXH.java`  |  **MSV:** `B21DCCN002`  |  **Mã đề:** `TU4ULIgh`

Sắp xếp rồi đếm bằng mảng `cnt`, mỗi phần tử phân biệt trả một xâu `"<giá trị>, <số lần>"`.

```java
package WebService.B21DCCN002;
import vn.medianews.*;
import java.util.*;
public class DemSoLanXH {
    public static void main(String[] args) throws Exception{
        String msv = "B21DCCN002", qCode = "TU4ULIgh"; 
        DataService_Service service = new DataService_Service();
        DataService port = service.getDataServicePort();
        List<Integer>a = port.getData(msv, qCode);
        System.out.println(a); Collections.sort(a);
        System.out.println(a);
        int []cnt = new int[10005];
        for(int x: a) cnt[x]++;
        List<String>ans = new java.util.ArrayList<>();
        for(int x: a){
            if(cnt[x]>0){
                String tmp = String.format("%d, %d", x, cnt[x]);
                ans.add(tmp);
                cnt[x] = 0;
            }
        }
        for(String x: ans){
            System.out.println(x);
        }
        port.submitDataStringArray(msv, qCode, ans);
    }
}
```

### 5. Loại bỏ phần tử trùng

**File gốc:** `WebService/B21DCCN033/LoaiBoTrungNhau.java`  |  **MSV:** `B21DCCN033`  |  **Mã đề:** `E2Axwwf3`

Giữ lần xuất hiện đầu tiên bằng mảng đếm, giữ nguyên thứ tự gốc.

```java
package WebService.B21DCCN033;
import vn.medianews.*;
import java.util.*;
public class LoaiBoTrungNhau {
    public static void main(String[] args) throws Exception{
        String msv = "B21DCCN033", qCode = "E2Axwwf3"; 
        DataService_Service service = new DataService_Service();
        DataService port = service.getDataServicePort();
        List<Integer>a = port.getData(msv, qCode);
        System.out.println(a);
        int []cnt = new int[10005];
        for(int x: a) cnt[x]++;
        List<Integer>ans = new java.util.ArrayList<>();
        for(int x: a){
            if(cnt[x]>0){
                ans.add(x);
                cnt[x] = 0;
            }
        }
        System.out.println(ans);
        port.submitDataIntArray(msv, qCode, ans);
    }
}
```

### 6. Lớn/nhỏ thứ K

**File gốc:** `WebService/B21DCCN003/LonNhoThuK.java`  |  **MSV:** `B21DCCN003`  |  **Mã đề:** `WpaUTFMu`

Phần tử đầu danh sách là `k`. Sắp xếp rồi lấy `a[k-1]` và `a[n-k]`.

```java
package WebService.B21DCCN003;
import vn.medianews.*;
import java.util.*;
public class LonNhoThuK {
    public static void main(String[] args) throws Exception{
        String msv = "B21DCCN003", qCode = "WpaUTFMu"; 
        DataService_Service service = new DataService_Service();
        DataService port = service.getDataServicePort();
        List<Integer>a = port.getData(msv, qCode);
        int k = a.get(0); a.remove(0);
        System.out.println(a + " " + k);
        Collections.sort(a);
        int nhoThuK = a.get(k - 1), lonThuK = a.get(a.size() - k);
        List<Integer>ans = new java.util.ArrayList<>(Arrays.asList(lonThuK, nhoThuK));
        port.submitDataIntArray(msv, qCode, ans);
    }
}
```

### 7. Sắp xếp xen kẽ chẵn — lẻ

**File gốc:** `WebService/B21DCCN088/SXChanLe.java`  |  **MSV:** `B21DCCN088`  |  **Mã đề:** `0BEtJAT9`

Tách 2 danh sách chẵn/lẻ, xen kẽ từng cặp, phần dư nối vào cuối.

```java
package WebService.B21DCCN088;
import vn.medianews.*;
import java.util.*;
public class SXChanLe {
    public static void main(String[] args) throws Exception{
        String msv = "B21DCCN088", qCode = "0BEtJAT9"; 
        DataService_Service service = new DataService_Service();
        DataService port = service.getDataServicePort();
        List<Integer>a = port.getData(msv, qCode);
        System.out.println(a);
        List<Integer>chan = new java.util.ArrayList<>(), le = new java.util.ArrayList<>(), ans = new java.util.ArrayList<>();
        for(int x: a){
            if(x%2==0) chan.add(x);
            else le.add(x);
        }
        int k = Integer.min(chan.size(), le.size());
        for(int i = 0;i < k;i++){
            ans.add(chan.get(i)); ans.add(le.get(i));
        }
        int k1 = chan.size() - k, k2 = le.size() - k;
        if(k1 > 0){
            for(int i = k;i<chan.size();i++) ans.add(chan.get(i));
        }
        if(k2 > 0){
            for(int i = k;i<le.size();i++) ans.add(le.get(i));
        }
        System.out.println(ans);
        port.submitDataIntArray(msv, qCode, ans);
    }
}
```

### 8. Thập phân → nhị phân

**File gốc:** `WebService/B21DCCN021/DecToBin.java`  |  **MSV:** `B21DCCN021`  |  **Mã đề:** `2jS1DTpU`

`Integer.toBinaryString` cho từng phần tử.

```java
package WebService.B21DCCN021;
import vn.medianews.*;
import java.util.*;
public class DecToBin {
    public static void main(String[] args) throws Exception{
        String msv = "B21DCCN021", qCode = "2jS1DTpU"; 
        DataService_Service service = new DataService_Service();
        DataService port = service.getDataServicePort();
        List<Integer>a = port.getData(msv, qCode);
        System.out.println(a);
        List<String>ans = new java.util.ArrayList<>();
        for(int x: a) ans.add(Integer.toBinaryString(x));
        System.out.println(ans);
        port.submitDataStringArray(msv, qCode, ans);
    }
}
```

### 9. Hệ cơ số 8 và 16

**File gốc:** `WebService/B21DCCN025/HeCoSo8.java`  |  **MSV:** `B21DCCN025`  |  **Mã đề:** `QBDJ1GGL`

Mỗi số → `"<bát phân>|<thập lục in hoa>"`.

```java
package WebService.B21DCCN025;
import vn.medianews.*;
import java.util.*;
public class HeCoSo8 {
    public static void main(String[] args) throws Exception{
        String msv = "B21DCCN025", qCode = "QBDJ1GGL"; 
        DataService_Service service = new DataService_Service();
        DataService port = service.getDataServicePort();
        List<Integer>a = port.getData(msv, qCode);
        System.out.println(a);
        List<String>res = new java.util.ArrayList<>();
        for(int n: a){
            String oct = Integer.toOctalString(n), hex = Integer.toHexString(n).toUpperCase();
            String tmp = oct + "|" + hex;
            res.add(tmp);
        }
        System.out.println(res);
        port.submitDataStringArray(msv, qCode, res);
    }
}
```

### 10. Số thập phân → phân số tối giản

**File gốc:** `WebService/B21DCCN011/FractoDec.java`  |  **MSV:** `B21DCCN011`  |  **Mã đề:** `ny8Fb8BU`

Làm tròn 2 chữ số → tử `= a*100`, mẫu `= 100` → rút gọn bằng `gcd`.

```java
package WebService.B21DCCN011;
import vn.medianews.*;
import java.util.*;
public class FractoDec {
    public static int gcd(int a, int b){
        while (b != 0) {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }
    public static void main(String[] args) throws Exception{
        String msv = "B21DCCN011", qCode = "ny8Fb8BU"; 
        DataService_Service service = new DataService_Service();
        DataService port = service.getDataServicePort();
        double a = port.getDataDouble(msv, qCode);
        a = Math.round(a * 100) / 100.0;
        System.out.println(a);
        int tu, mau = 100;
        tu = (int) (a * 100.0);
        int tmp = gcd(tu, mau); tu/=tmp; mau/=tmp;
        List<Integer> ans = new java.util.ArrayList<>();
        ans.add(tu); ans.add(mau);
        System.out.println(ans);
        port.submitDataIntArray(msv, qCode, ans);
    }
}
```

### 11. Ghép số lớn nhất

**File gốc:** `WebService/B21DCCN007/TimSoLonNhat.java`  |  **MSV:** `B21DCCN007`  |  **Mã đề:** `RiRH8wfk`

Chuyển các số về xâu, sắp xếp rồi ghép lại thành một số.

```java
package WebService.B21DCCN007;
import vn.medianews.*;
import java.util.*;
public class TimSoLonNhat {
    public static void main(String[] args) throws Exception{
        String msv = "B21DCCN007", qCode = "RiRH8wfk"; 
        DataService_Service service = new DataService_Service();
        DataService port = service.getDataServicePort();
        List<Integer>a = port.getData(msv, qCode);
        List<String>a1 = new java.util.ArrayList<>();
        for(int x: a) a1.add(x + "");
        Collections.sort(a1);
        String ans = "";
        for(String x: a1) ans+=x+ans;
        port.submitDataString(msv, qCode, ans);
    }
}
```

### B. CharacterService — 8 bài

### 12. Đảo ngược ký tự chữ cái

**File gốc:** `WebService/B21DCCN008/DaoNguoc.java`  |  **MSV:** `B21DCCN008`  |  **Mã đề:** `rT6Ql5GH`

Chỉ giữ ký tự chữ cái và đảo ngược thứ tự.

```java
package WebService.B21DCCN008;
import vn.medianews.*;
import java.util.*;
public class DaoNguoc {
    public static void main(String[] args) throws Exception {
        // Cấu hình thông tin
        String msv = "B21DCCN008", qCode = "rT6Ql5GH"; 
        // Tạo đối tượng dịch vụ từ web service
        CharacterService_Service service = new CharacterService_Service();
        CharacterService port = service.getCharacterServicePort();
        // a. Triệu gọi phương thức 
        String s = port.requestString(msv, qCode);
        System.out.println(s);
        //b.
        String ans = "";
        for(char x: s.toCharArray()){
            if(Character.isAlphabetic(x)) ans = x + ans;
        }
        System.out.println(ans);
        //c
        port.submitCharacterString(msv, qCode, ans);
    }
}
```

### 13. Từ dài nhất & ngắn nhất (trong xâu)

**File gốc:** `WebService/B21DCCN005/LenMaxMin.java`  |  **MSV:** `B21DCCN005`  |  **Mã đề:** `9n2rfqST`

Tách xâu theo khoảng trắng, tìm từ dài nhất và ngắn nhất, gửi `"<max>;<min>"`.

```java
package WebService.B21DCCN005;
import vn.medianews.*;
import java.util.*;
public class LenMaxMin {
    public static void main(String[] args) throws Exception {
        String msv = "B21DCCN005", qCode = "9n2rfqST"; 
        CharacterService_Service service = new CharacterService_Service();
        CharacterService port = service.getCharacterServicePort();
        String s = port.requestString(msv, qCode);
        System.out.println(s);
        String []tmp = s.trim().split("\\s+");
        int lenMax = tmp[0].length(), lenMin  = tmp[0].length();
        String strMax = tmp[0], strMin = tmp[0];
        for(String x: tmp){
            if(x.length() < lenMin){
                strMin = x;
                lenMin = x.length();
            }
            if(x.length() > lenMax){
                strMax = x;
                lenMax = x.length();
            }
        }
        String ans = strMax + ";" + strMin;
        System.out.println(ans);
        port.submitCharacterString(msv, qCode, ans);
    }
}
```

### 14. Từ dài nhất & ngắn nhất (trong mảng)

**File gốc:** `WebService/B21DCCN010/LenMaxMin2.java`  |  **MSV:** `B21DCCN010`  |  **Mã đề:** `sGJc3iD5`

Cùng yêu cầu nhưng đầu vào là `requestStringArray`.

```java
package WebService.B21DCCN010;
import vn.medianews.*;
import java.util.*;
public class LenMaxMin2 {
    public static void main(String[] args) throws Exception {
        String msv = "B21DCCN010", qCode = "sGJc3iD5"; 
        CharacterService_Service service = new CharacterService_Service();
        CharacterService port = service.getCharacterServicePort();
        List<String> a = port.requestStringArray(msv, qCode);
        String Max = a.get(0), Min = a.get(0);
        for(String x: a){
            if(x.length() > Max.length()) Max = x;
            if(x.length() < Min.length()) Min = x;
        }
        String ans = Max + ";" + Min;
        port.submitCharacterString(msv, qCode, ans);
    }
}
```

### 15. Sắp xếp chuỗi theo độ dài

**File gốc:** `WebService/B21DCCN003/SXTheoLen.java`  |  **MSV:** `B21DCCN003`  |  **Mã đề:** `mpu9xCxR`

`Collections.sort` với `Comparator` so sánh `length()`.

```java
package WebService.B21DCCN003;
import vn.medianews.*;
import java.util.*;
public class SXTheoLen {
    public static void main(String[] args) throws Exception {
        // Cấu hình thông tin
        String msv = "B21DCCN003", qCode = "mpu9xCxR"; 
        // Tạo đối tượng dịch vụ từ web service
        CharacterService_Service service = new CharacterService_Service();
        CharacterService port = service.getCharacterServicePort();
        // a. Triệu gọi phương thức requestStringArray từ server 
        List<String> a = port.requestStringArray(msv, qCode);
        // b. Sắp xếp các chuỗi theo số lượng nguyên âm
        Collections.sort(a, new Comparator<String>() {
            @Override
            public int compare(String s1, String s2) {
                return s1.length() - s2.length();
            }
        });
        // c. Triệu gọi phương thức submitCharacterStringArray để gửi mảng đã sắp xếp
        port.submitCharacterStringArray(msv, qCode, a);
        System.out.println(a);
    }
}
```

### 16. Sắp xếp chuỗi theo số nguyên âm

**File gốc:** `WebService/B21DCCN002/SapXepChuoi.java`  |  **MSV:** `B21DCCN002`  |  **Mã đề:** `x5TIDg1S`

`Comparator` so sánh số nguyên âm (`aeiouAEIOU`) trong mỗi chuỗi.

```java
package WebService.B21DCCN002;
import vn.medianews.*;
import java.util.*;
public class SapXepChuoi {
    public static void main(String[] args) throws Exception {
        // Cấu hình thông tin
        String msv = "B21DCCN002", qCode = "x5TIDg1S"; 
        // Tạo đối tượng dịch vụ từ web service
        CharacterService_Service service = new CharacterService_Service();
        CharacterService port = service.getCharacterServicePort();
        // a. Triệu gọi phương thức requestStringArray từ server 
        List<String> a = port.requestStringArray(msv, qCode);
        // b. Sắp xếp các chuỗi theo số lượng nguyên âm
        Collections.sort(a, new Comparator<String>() {
            @Override
            public int compare(String s1, String s2) {
                return dem(s1) - dem(s2);
            }
        });
        // c. Triệu gọi phương thức submitCharacterStringArray để gửi mảng đã sắp xếp
        port.submitCharacterStringArray(msv, qCode, a);
        System.out.println(a);
    }
    // Hàm đếm số nguyên âm trong chuỗi
    private static int dem(String str) {
        int cnt = 0;
        // Các ký tự nguyên âm
        String ngAm = "aeiouAEIOU";
        for (int i = 0; i < str.length(); i++) {
            if (ngAm.indexOf(str.charAt(i)) != -1) cnt++;
        }
        return cnt;
    }
}
```

### 17. Nhóm từ theo số nguyên âm

**File gốc:** `WebService/B21DCCN012/NhomTuTheoNguyenAm.java`  |  **MSV:** `B21DCCN012`  |  **Mã đề:** `32He7sZg`

Sắp xếp theo (số nguyên âm, thứ tự từ điển) rồi gom các từ cùng số nguyên âm vào một chuỗi.

```java
package WebService.B21DCCN012;
import vn.medianews.*;
import java.util.*;
public class NhomTuTheoNguyenAm {
    public static void main(String[] args) throws Exception {
        String msv = "B21DCCN012", qCode = "32He7sZg"; 
        CharacterService_Service service = new CharacterService_Service();
        CharacterService port = service.getCharacterServicePort();
        List<String> a = port.requestStringArray(msv, qCode);
        System.out.println(a);
        Collections.sort(a, new Comparator<String>() {
            @Override
            public int compare(String s1, String s2) {
                if(dem(s1)!=dem(s2)) return dem(s1) - dem(s2);
                return s1.compareTo(s2);
            }
        });
        List<String>ans = new java.util.ArrayList<>();
        String gr = a.get(0);
        for(int i = 1;i<a.size();i++){
            if(dem(a.get(i))==dem(a.get(i - 1))) gr+=", " + a.get(i);
            else{
                ans.add(gr);
                gr = a.get(i);
            }
        }
        ans.add(gr);
        // c. Triệu gọi phương thức submitCharacterStringArray để gửi mảng đã sắp xếp
        port.submitCharacterStringArray(msv, qCode, ans);
    }
    // Hàm đếm số nguyên âm trong chuỗi
    private static int dem(String str) {
        int cnt = 0;
        // Các ký tự nguyên âm
        String ngAm = "aeiouAEIOU";
        for (int i = 0; i < str.length(); i++) {
            if (ngAm.indexOf(str.charAt(i)) != -1) cnt++;
        }
        return cnt;
    }
}
```

### 18. Chuẩn hóa chuỗi 3 kiểu

**File gốc:** `WebService/B21DCCN007/ChuanHoaChuoi.java`  |  **MSV:** `B21DCCN007`  |  **Mã đề:** `sBQjqANT`

Sinh 3 dạng: PascalCase, camelCase và snake_case từ cùng một chuỗi.

```java
package WebService.B21DCCN007;
import vn.medianews.*;
import java.util.*;
public class ChuanHoaChuoi {
    public static void main(String[] args) throws Exception {
        // Cấu hình thông tin
        String msv = "B21DCCN007", qCode = "sBQjqANT"; 
        // Tạo đối tượng dịch vụ từ web service
        CharacterService_Service service = new CharacterService_Service();
        CharacterService port = service.getCharacterServicePort();
        // a. Triệu gọi phương thức 
        String s = port.requestString(msv, qCode);
        System.out.println(s);
        //b.
        s = s.replace('_', ' ');
        String []tmp = s.trim().split("\\s+");
        String p = "", c = tmp[0].toLowerCase(), sn = "";
        for(String x: tmp) p+=chuanhoa(x); 
        for(int i = 1;i<tmp.length;i++) c+=chuanhoa(tmp[i]);
        for(String x: tmp) sn+=x.toLowerCase()+"_"; sn = sn.substring(0, sn.length() - 1);
        List<String>ans = new java.util.ArrayList<>();
        ans.add(p); ans.add(c); ans.add(sn);
        System.out.println(ans);
        //c
        port.submitCharacterStringArray(msv, qCode, ans);
    }
    public static String chuanhoa(String s){
        return Character.toUpperCase(s.charAt(0)) + s.substring(1).toLowerCase();
    }
}
```

### 19. Xoay vòng ký tự

**File gốc:** `WebService/B21DCCN016/XoayVongKyTu.java`  |  **MSV:** `B21DCCN016`  |  **Mã đề:** `YDcPHFgN`

Số bước xoay = `a[0] % n`, dùng `Collections.rotate`.

```java
package WebService.B21DCCN016;
import vn.medianews.*;
import java.util.*;
public class XoayVongKyTu {
    public static void main(String[] args) throws Exception {
        String msv = "B21DCCN016", qCode = "YDcPHFgN"; 
        CharacterService_Service service = new CharacterService_Service();
        CharacterService port = service.getCharacterServicePort();
        List<Integer>a = port.requestCharacter(msv, qCode);
        int timeRot = a.get(0)%(a.size());
        Collections.rotate(a, timeRot);
        port.submitCharacterCharArray(msv, qCode, a);
    }
}
```

### C. ObjectService — 9 bài

### 20. Tính giá cuối — ProductY

**File gốc:** `WebService/B21DCCN002/QuanLySanPham.java`  |  **MSV:** `B21DCCN002`  |  **Mã đề:** `itT8hvxF`

`finalPrice = price * (1 + taxRate/100) * (1 - discount/100)`.

```java
package WebService.B21DCCN002;
import vn.medianews.*;
import java.util.*;
public class QuanLySanPham {
    public static void main(String[] args) throws Exception {
        String msv = "B21DCCN002", qCode = "itT8hvxF"; // Mã câu hỏi
        ObjectService_Service service = new ObjectService_Service();
        ObjectService port = service.getObjectServicePort();
        ProductY product = (ProductY) port.requestProductY(msv, qCode);
        System.out.println(product);
        float price = product.getPrice(), taxRate = product.getTaxRate(),discount = product.getDiscount();
        float finalPrice = price * (1 + taxRate / 100) * (1 - discount / 100);
        product.setFinalPrice(finalPrice);
        System.out.println(product);
        port.submitProductY(msv, qCode, product);
    }
}
```

### 21. Đếm ngày công — Employee

**File gốc:** `WebService/B21DCCN084/QuanLyNhanVien2.java`  |  **MSV:** `B21DCCN084`  |  **Mã đề:** `L8CainEX`

Duyệt từng ngày giữa `startDate` và `endDate`, đếm ngày có `getDayOfWeek().getValue() <= 5` (thứ 2 → thứ 6).

```java
package WebService.B21DCCN084;
import vn.medianews.*;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
public class QuanLyNhanVien2 {
    public static void main(String[] args) throws Exception{
        String msv = "B21DCCN084", qCode = "L8CainEX"; 
        ObjectService_Service service = new ObjectService_Service();
        ObjectService port = service.getObjectServicePort();
        Employee e = port.requestEmployee(msv, qCode);
        System.out.println(e);
        String bd = e.getStartDate().toString(), kt = e.getEndDate().toString();
        bd = bd.substring(0, 10); kt = kt.substring(0, 10);
        LocalDate stDay = LocalDate.parse(bd), enDay = LocalDate.parse(kt);
        long tmp = ChronoUnit.DAYS.between(stDay, enDay);
        int cnt = 0;
        for(int i = 0;i<=tmp;i++){
            LocalDate curDay = stDay.plusDays(i);
            if(curDay.getDayOfWeek().getValue()<=5) cnt++;
        }
        e.setWorkingDays(cnt);
        System.out.println(e);
        port.submitEmployee(msv, qCode, e);
    }
}
```

### 22. Phân loại học lực — Student

**File gốc:** `WebService/B21DCCN003/PhanLoaiHocLuc.java`  |  **MSV:** `B21DCCN003`  |  **Mã đề:** `qNfIMvid`

Lọc sinh viên có điểm ≥ 8.0 hoặc < 5.0.

```java
package WebService.B21DCCN003;
import vn.medianews.*;
import java.util.*;
public class PhanLoaiHocLuc {
    public static void main(String[] args) throws Exception {
        String msv = "B21DCCN003", qCode = "qNfIMvid"; // Mã câu hỏi
        ObjectService_Service service = new ObjectService_Service();
        ObjectService port = service.getObjectServicePort();
        List<Student> a = (List<Student>) port.requestListStudent(msv, qCode);
        for(Student x: a) System.out.println(x);
        System.out.println();
        List<Student>ans = new java.util.ArrayList<>();
        for(Student x: a){
            if(x.getScore() >=8.0) ans.add(x);
            else if (x.getScore() < 5) ans.add(x);
        }
        for(Student x: ans) System.out.println(x);
        port.submitListStudent(msv, qCode, ans);
    }
}
```

### 23. Thủ khoa từng môn — StudentY

**File gốc:** `WebService/B21DCCN001/QuanLySinhVien.java`  |  **MSV:** `B21DCCN001`  |  **Mã đề:** `2RjVBzv0`

Dùng `Map<môn, điểm cao nhất>` rồi lọc lại những sinh viên đạt điểm cao nhất.

```java
package WebService.B21DCCN001;
import vn.medianews.*;
import java.util.*;
public class QuanLySinhVien {
    public static void main(String[] args) throws Exception {
        String msv = "B21DCCN001", qCode = "2RjVBzv0"; // Mã câu hỏi
        ObjectService_Service service = new ObjectService_Service();
        ObjectService port = service.getObjectServicePort();
        List<StudentY> a = (List<StudentY>) port.requestListStudentY(msv, qCode);
        for (StudentY x : a) System.out.println(x);
        System.out.println();
        Map<String, Float> hsg = new HashMap<>(); //key: tên môn, value: điểm thi cao nhất môn đó
        for(StudentY x: a){
            String mon = x.getSubject();
            Float diemMon = x.getScore();
            if ((!hsg.containsKey(mon)) || (diemMon > hsg.get(mon))) hsg.put(mon, diemMon);
        }
        List<Float>diemMax = new java.util.ArrayList<>(hsg.values());
        List<StudentY>ans = new java.util.ArrayList<>();
        for(StudentY x: a){
            if(diemMax.contains(x.getScore())) ans.add(x);
        }
        port.submitListStudentY(msv, qCode, ans);
    }
} 
```

### 24. Sắp xếp theo ngày vào làm — EmployeeY

**File gốc:** `WebService/B21DCCN004/QuanLyNhanVien.java`  |  **MSV:** `B21DCCN004`  |  **Mã đề:** `vewbvojZ`

`Comparator` dùng `XMLGregorianCalendar.compare` trên `startDate`.

```java
package WebService.B21DCCN004;
import vn.medianews.*;
import java.util.*;
public class QuanLyNhanVien {
    public static void main(String[] args) throws Exception {
        String msv = "B21DCCN004", qCode = "vewbvojZ"; 
        ObjectService_Service service = new ObjectService_Service();
        ObjectService port = service.getObjectServicePort(); 
        List<EmployeeY>a = port.requestListEmployeeY(msv, qCode);
        for(EmployeeY x: a) System.out.println(x);
        Collections.sort(a, new Comparator<EmployeeY>(){
            @Override
            public int compare(EmployeeY o1, EmployeeY o2) {
                return o1.getStartDate().compare(o2.getStartDate());
            }
        });
        System.out.println();
        for(EmployeeY x: a) System.out.println(x);
        port.submitListEmployeeY(msv, qCode, a);
    }
}
```

### 25. Khách hàng thân thiết — Customer

**File gốc:** `WebService/B21DCCN014/QuanLyKhachHang.java`  |  **MSV:** `B21DCCN014`  |  **Mã đề:** `lgKj7lIF`

Lọc khách có `totalSpent > 5000` và `purchaseCount >= 5`.

```java
package WebService.B21DCCN014;
import vn.medianews.*;
import java.util.*;
public class QuanLyKhachHang {
    public static void main(String[] args) throws Exception{
        String msv = "B21DCCN014", qCode = "lgKj7lIF"; 
        ObjectService_Service service = new ObjectService_Service();
        ObjectService port = service.getObjectServicePort();
        List<Customer>a = (List<Customer>)port.requestListCustomer(msv, qCode);
        for(Customer x: a) System.out.println(x);
        List<Customer>ans = new java.util.ArrayList<>();
        for(Customer x: a){
            if(x.getTotalSpent() > 5000 && x.getPurchaseCount() >=5) ans.add(x);
        }
        System.out.println();
        for(Customer x: ans) System.out.println(x);
        port.submitListCustomer(msv, qCode, ans);
    }
}
```

### 26. Khách hàng không hoạt động — CustomerY

**File gốc:** `WebService/B21DCCN005/QuanLyKhachHang.java`  |  **MSV:** `B21DCCN005`  |  **Mã đề:** `aYiLQ3wo`

`ChronoUnit.MONTHS` giữa `lastTransactionDate` và hôm nay ≥ 6 tháng.

```java
package WebService.B21DCCN005;
import java.util.*;
import java.time.*;
import java.time.temporal.ChronoUnit;
import vn.medianews.*;
public class QuanLyKhachHang {
    public static void main(String[] args) throws Exception {
        String msv = "B21DCCN005", qCode = "aYiLQ3wo";
        ObjectService_Service service = new ObjectService_Service();
        ObjectService port = service.getObjectServicePort();
        List<CustomerY> cus = (List<CustomerY>) port.requestListCustomerY(msv, qCode);
        for (CustomerY x: cus) System.out.println(x);
        System.out.println();
        LocalDate today = LocalDate.now();
        List<CustomerY> ans = new ArrayList<>();
        for (CustomerY x: cus) {
            String t = x.getLastTransactionDate().toString();
            t = t.substring(0, 10);
            LocalDate old = LocalDate.parse(t);
            long thang = ChronoUnit.MONTHS.between(old, today);
            if(thang >=6) ans.add(x);
        }
        for (CustomerY x: ans) System.out.println(x);
        port.submitListCustomerY(msv, qCode, ans);
    }
}
```

### 27. Dự án sắp tới hạn — Project

**File gốc:** `WebService/B21DCCN010/QuanLyDuAn.java`  |  **MSV:** `B21DCCN010`  |  **Mã đề:** `R6UOuyyE`

Còn 0–15 ngày tới `dueDate` và `completionPercentage >= 80`.

```java
package WebService.B21DCCN010;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import vn.medianews.*;
import java.util.*;
public class QuanLyDuAn {
    public static void main(String[] args) throws Exception {
        String msv = "B21DCCN010", qCode = "R6UOuyyE";
        ObjectService_Service service = new ObjectService_Service();
        ObjectService port = service.getObjectServicePort();
        List<Project>a = (List<Project>)port.requestListProject(msv, qCode);
        for(Project p: a) System.out.println(p);
        System.out.println();
        List<Project> send = new java.util.ArrayList<>();
        LocalDate today = LocalDate.now();
        for(Project x : a){
            String t = x.getDueDate().toString();
            t = t.substring(0, 10);
            LocalDate future = LocalDate.parse(t);
            long ngay = ChronoUnit.DAYS.between(today, future);
            if(ngay <=15 && ngay >=0 && x.getCompletionPercentage() >=80.00) send.add(x);
        }
        port.submitListProject(msv, qCode, send);
        for(Project p: send) System.out.println(p);
    }
}
```

### 28. Khách chi nhiều nhất — Order

**File gốc:** `WebService/B21DCCN021/DonHang2.java`  |  **MSV:** `B21DCCN021`  |  **Mã đề:** `CuW1L0ev`

Cộng dồn `amount` theo `customerId`, tìm khách có tổng lớn nhất rồi lọc mọi đơn của khách đó.

```java
package WebService.B21DCCN021;
import vn.medianews.*;
import java.util.*;
public class DonHang2 {
    public static void main(String[] args) throws Exception{
        String msv = "B21DCCN021", qCode = "CuW1L0ev"; 
        ObjectService_Service service = new ObjectService_Service();
        ObjectService port = service.getObjectServicePort();
        List<Order>a = (List<Order>)port.requestListOrder(msv, qCode);
        for(Order x: a) System.out.println(x);
        HashMap<String, Float>mp = new HashMap<>();
        for(Order x: a){
            String maKH = x.getCustomerId(); float giaTri = x.getAmount();
            if(!mp.containsKey(maKH)) mp.put(maKH, giaTri);
            else mp.put(maKH, mp.get(maKH) + giaTri);
        }
        float maxGiaTri = 0; String maKHmax = "";
        for (String maKH: mp.keySet()) {
            float giaTri = mp.get(maKH);
            if (giaTri > maxGiaTri) {
                maxGiaTri = giaTri;
                maKHmax = maKH;
            }
        }
        List<Order>ans = new java.util.ArrayList<>();
        for(Order x: a){
            if(x.getCustomerId().equals(maKHmax)) ans.add(x);
        }
        port.submitListOrder(msv, qCode, ans);
    }
}
```
